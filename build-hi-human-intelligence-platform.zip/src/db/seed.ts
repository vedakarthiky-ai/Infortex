import { count } from "drizzle-orm";
import { db } from "@/db";
import { comments, posts, projects, users } from "@/db/schema";
import { hashPassword } from "@/lib/auth";

const demoPeople = [
  {
    id: "10000000-0000-4000-8000-000000000001",
    name: "Maya Chen",
    email: "maya@hi.community",
    headline: "Product designer · San Francisco",
    bio: "Designing calmer, more human technology. Always happy to talk portfolios and career pivots.",
    location: "San Francisco, CA",
    skills: ["Product design", "Research", "Figma"],
    interests: ["Design", "Startups", "Mentorship"],
    verified: true,
    contributionScore: 1240,
  },
  {
    id: "10000000-0000-4000-8000-000000000002",
    name: "Aisha Rahman",
    email: "aisha@hi.community",
    headline: "Software engineer · London",
    bio: "Building reliable systems and helping early-career engineers find their footing.",
    location: "London, UK",
    skills: ["TypeScript", "Backend", "Mentoring"],
    interests: ["Technology", "Programming", "Career"],
    verified: true,
    contributionScore: 2180,
  },
  {
    id: "10000000-0000-4000-8000-000000000003",
    name: "Theo Park",
    email: "theo@hi.community",
    headline: "Founder & climate researcher · Seoul",
    bio: "Turning research into useful things. Here for thoughtful collaboration, not pitch decks.",
    location: "Seoul, South Korea",
    skills: ["Climate tech", "Research", "Startups"],
    interests: ["Science", "Startups", "Open source"],
    verified: true,
    contributionScore: 975,
  },
  {
    id: "10000000-0000-4000-8000-000000000004",
    name: "Elena García",
    email: "elena@hi.community",
    headline: "Professor of human-computer interaction · Madrid",
    bio: "Researching how people learn together. Ask me about graduate school, research, or teaching.",
    location: "Madrid, Spain",
    skills: ["HCI", "Teaching", "Research"],
    interests: ["Education", "Science", "Design"],
    verified: true,
    contributionScore: 1635,
  },
  {
    id: "10000000-0000-4000-8000-000000000005",
    name: "Malik Johnson",
    email: "malik@hi.community",
    headline: "Community builder · New York",
    bio: "Helping good ideas find good people. Started my first company at 24 and learned a lot the hard way.",
    location: "New York, NY",
    skills: ["Community", "Strategy", "Fundraising"],
    interests: ["Business", "Startups", "Books"],
    verified: false,
    contributionScore: 840,
  },
];

const seedPosts = [
  {
    id: "20000000-0000-4000-8000-000000000001",
    authorId: demoPeople[1].id,
    kind: "experience",
    title: "What I wish I knew before my first engineering job",
    body: "Your first six months are mostly about learning how the team thinks. Ask why a decision was made, keep a tiny decision journal, and find one person who will give you honest feedback. The code gets easier; understanding the context is the real superpower.",
    community: "Technology",
    tags: ["Career", "Engineering", "First job"],
    likes: 48,
  },
  {
    id: "20000000-0000-4000-8000-000000000002",
    authorId: demoPeople[2].id,
    kind: "question",
    title: "How do you know when a research idea is ready to become a product?",
    body: "We have a small open-source tool that climate researchers genuinely use. I’m curious what signals helped you move from a promising prototype to something people depend on. Especially interested in the messy middle.",
    community: "Startups",
    tags: ["Climate tech", "Product", "Research"],
    likes: 32,
  },
  {
    id: "20000000-0000-4000-8000-000000000003",
    authorId: demoPeople[0].id,
    kind: "discussion",
    title: "A small reminder: your portfolio is a conversation, not a museum",
    body: "The strongest portfolios I review explain the choices behind the work. What did you notice? What changed your mind? What would you do differently? Showing your thinking makes it much easier for someone to imagine working with you.",
    community: "Design",
    tags: ["Design", "Portfolio", "Advice"],
    likes: 61,
  },
  {
    id: "20000000-0000-4000-8000-000000000004",
    authorId: demoPeople[3].id,
    kind: "discussion",
    title: "What makes a mentor relationship actually work?",
    body: "The best mentoring I’ve experienced had one thing in common: a specific question to work on together. Not 'tell me how to succeed' but 'here is the decision I’m facing this month.' What has worked for you?",
    community: "Career",
    tags: ["Mentorship", "Career growth"],
    likes: 27,
  },
  {
    id: "20000000-0000-4000-8000-000000000005",
    authorId: demoPeople[4].id,
    kind: "idea",
    title: "Could we make a map of the skills people actually use to start a company?",
    body: "Not another founder checklist. I’m imagining a living map of real stories: the first customer conversation, a hiring mistake, a partnership that changed everything. Looking for people who would help shape it.",
    community: "Business",
    tags: ["Founder stories", "Collaboration", "Ideas"],
    likes: 19,
  },
  {
    id: "20000000-0000-4000-8000-000000000006",
    authorId: demoPeople[0].id,
    kind: "experience",
    title: "My honest notes on switching from agency work to a startup",
    body: "I traded clear briefs and polished handoffs for ambiguity and a seat at the table. The first month felt like I had forgotten how to design. Six months later, I understand the customer and the business in a way I never did before. Both paths taught me something different.",
    community: "Design",
    tags: ["Career change", "Startups", "Design"],
    likes: 36,
  },
];

const seedProjects = [
  {
    id: "40000000-0000-4000-8000-000000000001",
    creatorId: demoPeople[2].id,
    title: "Fieldnotes for a cooler city",
    description: "An open map of small, local climate adaptations—from shaded bus stops to community fridges. We’re building a friendly way for neighbors to document what works and share it with other cities.",
    category: "Climate & community",
    lookingFor: "Frontend engineer · Urban planner · Writers",
    skills: ["React", "Mapping", "Community research"],
  },
  {
    id: "40000000-0000-4000-8000-000000000002",
    creatorId: demoPeople[0].id,
    title: "Open Hand — a kinder portfolio review",
    description: "A small peer-to-peer portfolio circle for designers making a career move. Thoughtful feedback, no scoring, and a real human on the other side of every review.",
    category: "Design & education",
    lookingFor: "Designers · Community host",
    skills: ["Product design", "Community", "Writing"],
  },
  {
    id: "40000000-0000-4000-8000-000000000003",
    creatorId: demoPeople[1].id,
    title: "Tiny Wins: open-source onboarding",
    description: "A collection of bite-sized first issues and human-written context that helps new contributors make their first meaningful open-source contribution.",
    category: "Open source",
    lookingFor: "Maintainers · Technical writers · Beginners",
    skills: ["TypeScript", "Open source", "Developer experience"],
  },
  {
    id: "40000000-0000-4000-8000-000000000004",
    creatorId: demoPeople[4].id,
    title: "First 100 conversations",
    description: "A practical, honest playbook of early customer discovery stories from founders around the world. The awkward calls, surprising answers, and what changed next.",
    category: "Startups & research",
    lookingFor: "Founders · Researchers · Illustrators",
    skills: ["User research", "Storytelling", "Startups"],
  },
];

const seedComments = [
  { id: "30000000-0000-4000-8000-000000000001", postId: seedPosts[0].id, authorId: demoPeople[3].id, body: "The decision journal idea is excellent. I ask new researchers to do the same thing." },
  { id: "30000000-0000-4000-8000-000000000002", postId: seedPosts[0].id, authorId: demoPeople[0].id, body: "Context really is the unlock. I wish someone had told me this in week one." },
  { id: "30000000-0000-4000-8000-000000000003", postId: seedPosts[1].id, authorId: demoPeople[4].id, body: "For us it was when people began asking if they could bring a colleague along." },
  { id: "30000000-0000-4000-8000-000000000004", postId: seedPosts[2].id, authorId: demoPeople[3].id, body: "Yes to this. A clear story about a hard decision is more memorable than ten perfect screens." },
  { id: "30000000-0000-4000-8000-000000000005", postId: seedPosts[3].id, authorId: demoPeople[1].id, body: "Having a real question to focus on has made every mentoring session better for me." },
];

export async function ensureSeedData() {
  const [existingPosts] = await db.select({ value: count() }).from(posts);
  if (Number(existingPosts?.value ?? 0) > 0) return;

  const demoPassword = hashPassword("humanfirst");
  await db
    .insert(users)
    .values(demoPeople.map((person) => ({ ...person, passwordHash: demoPassword })))
    .onConflictDoNothing();

  await db.insert(posts).values(
    seedPosts.map((post, index) => ({
      ...post,
      createdAt: new Date(Date.now() - (index * 2 + 2) * 60 * 60 * 1000),
    })),
  ).onConflictDoNothing();

  await db.insert(projects).values(
    seedProjects.map((project, index) => ({
      ...project,
      createdAt: new Date(Date.now() - (index + 1) * 24 * 60 * 60 * 1000),
    })),
  ).onConflictDoNothing();

  await db.insert(comments).values(seedComments).onConflictDoNothing();
}
