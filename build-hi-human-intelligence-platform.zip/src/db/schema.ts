import { sql } from "drizzle-orm";
import {
  boolean,
  index,
  integer,
  pgTable,
  primaryKey,
  text,
  timestamp,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

export const users = pgTable("hi_users", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  headline: varchar("headline", { length: 180 }).notNull().default("Curious human"),
  bio: text("bio").notNull().default(""),
  location: varchar("location", { length: 120 }).notNull().default(""),
  skills: text("skills").array().notNull().default(sql`ARRAY[]::text[]`),
  interests: text("interests").array().notNull().default(sql`ARRAY[]::text[]`),
  verified: boolean("verified").notNull().default(false),
  contributionScore: integer("contribution_score").notNull().default(0),
  ageConfirmedAt: timestamp("age_confirmed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable(
  "hi_sessions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    tokenHash: varchar("token_hash", { length: 64 }).notNull().unique(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("hi_sessions_user_id_idx").on(table.userId)],
);

export const posts = pgTable(
  "hi_posts",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    authorId: uuid("author_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    kind: varchar("kind", { length: 32 }).notNull().default("discussion"),
    title: varchar("title", { length: 180 }).notNull(),
    body: text("body").notNull(),
    community: varchar("community", { length: 80 }).notNull().default("General"),
    tags: text("tags").array().notNull().default(sql`ARRAY[]::text[]`),
    likes: integer("likes").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("hi_posts_created_at_idx").on(table.createdAt), index("hi_posts_author_id_idx").on(table.authorId)],
);

export const projects = pgTable(
  "hi_projects",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    creatorId: uuid("creator_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 160 }).notNull(),
    description: text("description").notNull(),
    category: varchar("category", { length: 80 }).notNull().default("Open source"),
    lookingFor: varchar("looking_for", { length: 180 }).notNull().default("Collaborators"),
    skills: text("skills").array().notNull().default(sql`ARRAY[]::text[]`),
    status: varchar("status", { length: 32 }).notNull().default("Open to collaborators"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("hi_projects_created_at_idx").on(table.createdAt), index("hi_projects_creator_id_idx").on(table.creatorId)],
);

export const comments = pgTable(
  "hi_comments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    postId: uuid("post_id").notNull().references(() => posts.id, { onDelete: "cascade" }),
    authorId: uuid("author_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    body: text("body").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("hi_comments_post_id_idx").on(table.postId)],
);

export const postLikes = pgTable(
  "hi_post_likes",
  {
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    postId: uuid("post_id").notNull().references(() => posts.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [primaryKey({ columns: [table.userId, table.postId] })],
);

export const bookmarks = pgTable(
  "hi_bookmarks",
  {
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    postId: uuid("post_id").notNull().references(() => posts.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [primaryKey({ columns: [table.userId, table.postId] })],
);

export const contactMessages = pgTable("hi_contact_messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  topic: varchar("topic", { length: 80 }).notNull().default("General question"),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
