import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "HI — Human Intelligence",
  description: "Real people. Real intelligence. Find mentors, share experience, and solve meaningful problems together.",
  applicationName: "HI — Human Intelligence",
  keywords: ["human intelligence", "mentorship", "community", "collaboration", "real experiences"],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
