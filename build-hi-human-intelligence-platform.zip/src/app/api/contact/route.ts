import { db } from "@/db";
import { contactMessages } from "@/db/schema";

export async function POST(request: Request) {
  const payload = await request.json().catch(() => null);
  const name = typeof payload?.name === "string" ? payload.name.trim().slice(0, 100) : "";
  const email = typeof payload?.email === "string" ? payload.email.trim().toLowerCase().slice(0, 255) : "";
  const topic = typeof payload?.topic === "string" ? payload.topic.trim().slice(0, 80) : "General question";
  const message = typeof payload?.message === "string" ? payload.message.trim().slice(0, 4000) : "";

  if (name.length < 2) return Response.json({ error: "Please enter your name." }, { status: 400 });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return Response.json({ error: "Enter a valid email address." }, { status: 400 });
  if (message.length < 20) return Response.json({ error: "A little more context will help a human get back to you." }, { status: 400 });

  await db.insert(contactMessages).values({ name, email, topic: topic || "General question", message });
  return Response.json({ ok: true }, { status: 201 });
}
