import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { bookmarks } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  const currentUser = await getCurrentUser();
  if (!currentUser) return Response.json({ ids: [] });
  const rows = await db.select({ postId: bookmarks.postId }).from(bookmarks).where(eq(bookmarks.userId, currentUser.id));
  return Response.json({ ids: rows.map((row) => row.postId) });
}

export async function POST(request: Request) {
  const currentUser = await getCurrentUser();
  if (!currentUser) return Response.json({ error: "Sign in to save a conversation." }, { status: 401 });
  const payload = await request.json().catch(() => null);
  const postId = typeof payload?.postId === "string" ? payload.postId : "";
  if (!/^[0-9a-f-]{36}$/i.test(postId)) return Response.json({ error: "That conversation could not be found." }, { status: 400 });

  const [existing] = await db.select({ postId: bookmarks.postId }).from(bookmarks)
    .where(and(eq(bookmarks.userId, currentUser.id), eq(bookmarks.postId, postId))).limit(1);
  if (existing) {
    await db.delete(bookmarks).where(and(eq(bookmarks.userId, currentUser.id), eq(bookmarks.postId, postId)));
    return Response.json({ saved: false });
  }
  await db.insert(bookmarks).values({ userId: currentUser.id, postId }).onConflictDoNothing();
  return Response.json({ saved: true });
}
