import { and, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { comments, postLikes, posts, users } from "@/db/schema";
import { ensureSeedData } from "@/db/seed";
import { getCurrentUser } from "@/lib/auth";

function cleanTags(value: unknown) {
  if (!Array.isArray(value)) return [];
  return value
    .filter((tag): tag is string => typeof tag === "string")
    .map((tag) => tag.trim().replace(/^#/, "").slice(0, 32))
    .filter(Boolean)
    .slice(0, 6);
}

export async function GET() {
  await ensureSeedData();
  const currentUser = await getCurrentUser();
  const rows = await db
    .select({
      id: posts.id,
      authorId: posts.authorId,
      kind: posts.kind,
      title: posts.title,
      body: posts.body,
      community: posts.community,
      tags: posts.tags,
      likes: posts.likes,
      createdAt: posts.createdAt,
      authorName: users.name,
      authorHeadline: users.headline,
      authorVerified: users.verified,
      authorScore: users.contributionScore,
    })
    .from(posts)
    .innerJoin(users, eq(posts.authorId, users.id))
    .orderBy(desc(posts.createdAt))
    .limit(30);

  const ids = rows.map((post) => post.id);
  const replyRows = ids.length
    ? await db
        .select({
          id: comments.id,
          postId: comments.postId,
          body: comments.body,
          createdAt: comments.createdAt,
          authorId: users.id,
          authorName: users.name,
          authorHeadline: users.headline,
        })
        .from(comments)
        .innerJoin(users, eq(comments.authorId, users.id))
        .where(inArray(comments.postId, ids))
        .orderBy(comments.createdAt)
    : [];
  const likedIds = currentUser && ids.length
    ? await db.select({ postId: postLikes.postId }).from(postLikes).where(and(eq(postLikes.userId, currentUser.id), inArray(postLikes.postId, ids)))
    : [];
  const repliesByPost = new Map<string, typeof replyRows>();
  for (const reply of replyRows) {
    const replies = repliesByPost.get(reply.postId) ?? [];
    replies.push(reply);
    repliesByPost.set(reply.postId, replies);
  }
  const likedSet = new Set(likedIds.map((item) => item.postId));

  return Response.json({
    posts: rows.map((post) => ({
      id: post.id,
      authorId: post.authorId,
      kind: post.kind,
      title: post.title,
      body: post.body,
      community: post.community,
      tags: post.tags,
      likes: post.likes,
      createdAt: post.createdAt,
      likedByMe: likedSet.has(post.id),
      author: {
        id: post.authorId,
        name: post.authorName,
        headline: post.authorHeadline,
        verified: post.authorVerified,
        contributionScore: post.authorScore,
      },
      comments: (repliesByPost.get(post.id) ?? []).map((reply) => ({
        id: reply.id,
        postId: reply.postId,
        body: reply.body,
        createdAt: reply.createdAt,
        author: { id: reply.authorId, name: reply.authorName, headline: reply.authorHeadline },
      })),
    })),
  });
}

export async function POST(request: Request) {
  const currentUser = await getCurrentUser();
  if (!currentUser) return Response.json({ error: "Sign in to start a conversation." }, { status: 401 });
  const payload = await request.json().catch(() => null);
  const title = typeof payload?.title === "string" ? payload.title.trim().slice(0, 180) : "";
  const body = typeof payload?.body === "string" ? payload.body.trim().slice(0, 4000) : "";
  const community = typeof payload?.community === "string" ? payload.community.trim().slice(0, 80) : "General";
  const kind = ["discussion", "question", "experience", "idea"].includes(payload?.kind) ? payload.kind : "discussion";
  if (title.length < 5 || body.length < 12) {
    return Response.json({ error: "Add a title and a little more detail so people can help." }, { status: 400 });
  }

  const [created] = await db.insert(posts).values({
    authorId: currentUser.id,
    title,
    body,
    community: community || "General",
    kind,
    tags: cleanTags(payload?.tags),
  }).returning();

  return Response.json({
    post: {
      ...created,
      likedByMe: false,
      comments: [],
      author: {
        id: currentUser.id,
        name: currentUser.name,
        headline: currentUser.headline,
        verified: currentUser.verified,
        contributionScore: currentUser.contributionScore,
      },
    },
  }, { status: 201 });
}
