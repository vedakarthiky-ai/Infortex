import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { postLikes, posts } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

type RouteContext = { params: Promise<{ id: string }> };

export async function POST(_request: Request, context: RouteContext) {
  const currentUser = await getCurrentUser();
  if (!currentUser) return Response.json({ error: "Sign in to appreciate a contribution." }, { status: 401 });
  const { id } = await context.params;

  const result = await db.transaction(async (tx) => {
    const [existing] = await tx.select({ postId: postLikes.postId }).from(postLikes)
      .where(and(eq(postLikes.userId, currentUser.id), eq(postLikes.postId, id))).limit(1);
    let liked: boolean;
    if (existing) {
      await tx.delete(postLikes).where(and(eq(postLikes.userId, currentUser.id), eq(postLikes.postId, id)));
      liked = false;
    } else {
      await tx.insert(postLikes).values({ userId: currentUser.id, postId: id }).onConflictDoNothing();
      liked = true;
    }
    const [updated] = await tx.update(posts).set({
      likes: sql`greatest(${posts.likes} + ${liked ? 1 : -1}, 0)`,
    }).where(eq(posts.id, id)).returning({ likes: posts.likes });
    return { liked, likes: updated?.likes };
  });

  if (result.likes === undefined) return Response.json({ error: "That conversation could not be found." }, { status: 404 });
  return Response.json(result);
}
