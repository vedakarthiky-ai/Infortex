import { eq } from "drizzle-orm";
import { db } from "@/db";
import { comments, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

type RouteContext = { params: Promise<{ id: string }> };

export async function POST(request: Request, context: RouteContext) {
  const currentUser = await getCurrentUser();
  if (!currentUser) return Response.json({ error: "Sign in to share your perspective." }, { status: 401 });
  const { id: postId } = await context.params;
  const payload = await request.json().catch(() => null);
  const body = typeof payload?.body === "string" ? payload.body.trim().slice(0, 1200) : "";
  if (body.length < 2) return Response.json({ error: "Write a little more before replying." }, { status: 400 });

  const [created] = await db.insert(comments).values({ postId, authorId: currentUser.id, body }).returning();
  if (!created) return Response.json({ error: "Couldn’t add that reply." }, { status: 500 });
  return Response.json({
    comment: {
      ...created,
      author: { id: currentUser.id, name: currentUser.name, headline: currentUser.headline },
    },
  }, { status: 201 });
}
