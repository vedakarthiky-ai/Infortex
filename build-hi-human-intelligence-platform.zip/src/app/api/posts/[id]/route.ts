import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { posts } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

type RouteContext = { params: Promise<{ id: string }> };

function cleanTags(value: unknown) {
  if (!Array.isArray(value)) return [];
  return value.filter((tag): tag is string => typeof tag === "string").map((tag) => tag.trim().replace(/^#/, "").slice(0, 32)).filter(Boolean).slice(0, 6);
}

export async function PATCH(request: Request, context: RouteContext) {
  const currentUser = await getCurrentUser();
  if (!currentUser) return Response.json({ error: "Sign in to edit your post." }, { status: 401 });
  const { id } = await context.params;
  const payload = await request.json().catch(() => null);
  const title = typeof payload?.title === "string" ? payload.title.trim().slice(0, 180) : "";
  const body = typeof payload?.body === "string" ? payload.body.trim().slice(0, 4000) : "";
  const community = typeof payload?.community === "string" ? payload.community.trim().slice(0, 80) : "";
  const kind = ["discussion", "question", "experience", "idea"].includes(payload?.kind) ? payload.kind : "discussion";
  if (title.length < 5 || body.length < 12 || !community) {
    return Response.json({ error: "Add a title, community, and a little more detail." }, { status: 400 });
  }

  const [updated] = await db.update(posts).set({ title, body, community, kind, tags: cleanTags(payload?.tags) })
    .where(and(eq(posts.id, id), eq(posts.authorId, currentUser.id))).returning();
  if (!updated) return Response.json({ error: "Post not found or you don’t have permission to edit it." }, { status: 404 });
  return Response.json({ post: updated });
}

export async function DELETE(_request: Request, context: RouteContext) {
  const currentUser = await getCurrentUser();
  if (!currentUser) return Response.json({ error: "Sign in to delete your post." }, { status: 401 });
  const { id } = await context.params;
  const [deleted] = await db.delete(posts).where(and(eq(posts.id, id), eq(posts.authorId, currentUser.id))).returning({ id: posts.id });
  if (!deleted) return Response.json({ error: "Post not found or you don’t have permission to delete it." }, { status: 404 });
  return Response.json({ ok: true, id: deleted.id });
}
