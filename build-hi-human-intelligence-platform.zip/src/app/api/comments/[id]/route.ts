import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { comments } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, context: RouteContext) {
  const currentUser = await getCurrentUser();
  if (!currentUser) return Response.json({ error: "Sign in to edit your reply." }, { status: 401 });
  const { id } = await context.params;
  const payload = await request.json().catch(() => null);
  const body = typeof payload?.body === "string" ? payload.body.trim().slice(0, 1200) : "";
  if (body.length < 2) return Response.json({ error: "Write a little more before saving." }, { status: 400 });
  const [updated] = await db.update(comments).set({ body }).where(and(eq(comments.id, id), eq(comments.authorId, currentUser.id))).returning();
  if (!updated) return Response.json({ error: "Reply not found or you don’t have permission to edit it." }, { status: 404 });
  return Response.json({ comment: updated });
}

export async function DELETE(_request: Request, context: RouteContext) {
  const currentUser = await getCurrentUser();
  if (!currentUser) return Response.json({ error: "Sign in to delete your reply." }, { status: 401 });
  const { id } = await context.params;
  const [deleted] = await db.delete(comments).where(and(eq(comments.id, id), eq(comments.authorId, currentUser.id))).returning({ id: comments.id });
  if (!deleted) return Response.json({ error: "Reply not found or you don’t have permission to delete it." }, { status: 404 });
  return Response.json({ ok: true, id: deleted.id });
}
