import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, hashPassword } from "@/lib/auth";

export async function POST(request: Request) {
  const payload = await request.json().catch(() => null);
  const name = typeof payload?.name === "string" ? payload.name.trim() : "";
  const email = typeof payload?.email === "string" ? payload.email.trim().toLowerCase() : "";
  const password = typeof payload?.password === "string" ? payload.password : "";

  if (name.length < 2 || name.length > 80) {
    return Response.json({ error: "Please enter a name between 2 and 80 characters." }, { status: 400 });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return Response.json({ error: "Enter a valid email address." }, { status: 400 });
  }
  if (password.length < 8 || password.length > 128) {
    return Response.json({ error: "Choose a password with at least 8 characters." }, { status: 400 });
  }
  if (payload?.ageConfirmed !== true) {
    return Response.json({ error: "HI is for people aged 18 and older. Please confirm your age to continue." }, { status: 400 });
  }

  const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing) return Response.json({ error: "An account with this email already exists." }, { status: 409 });

  const [user] = await db
    .insert(users)
    .values({ name, email, passwordHash: hashPassword(password), headline: "Curious human", ageConfirmedAt: new Date() })
    .returning({
      id: users.id,
      name: users.name,
      email: users.email,
      headline: users.headline,
      bio: users.bio,
      location: users.location,
      skills: users.skills,
      interests: users.interests,
      verified: users.verified,
      contributionScore: users.contributionScore,
      createdAt: users.createdAt,
    });

  if (!user) return Response.json({ error: "We couldn’t create your account. Please try again." }, { status: 500 });
  await createSession(user.id);
  return Response.json({ user }, { status: 201 });
}
