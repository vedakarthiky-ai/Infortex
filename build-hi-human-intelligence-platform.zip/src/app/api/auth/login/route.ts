import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { ensureSeedData } from "@/db/seed";
import { createSession, verifyPassword } from "@/lib/auth";

export async function POST(request: Request) {
  await ensureSeedData();
  const payload = await request.json().catch(() => null);
  const email = typeof payload?.email === "string" ? payload.email.trim().toLowerCase() : "";
  const password = typeof payload?.password === "string" ? payload.password : "";
  if (!email || !password) return Response.json({ error: "Enter your email and password." }, { status: 400 });

  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return Response.json({ error: "That email and password combination didn’t match." }, { status: 401 });
  }

  await createSession(user.id);
  const { passwordHash: _passwordHash, ...safeUser } = user;
  return Response.json({ user: safeUser });
}
