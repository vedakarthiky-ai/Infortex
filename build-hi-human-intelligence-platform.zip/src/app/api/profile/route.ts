import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

function cleanList(value: unknown) {
  if (!Array.isArray(value)) return undefined;
  return value
    .filter((item): item is string => typeof item === "string")
    .map((item) => item.trim().slice(0, 48))
    .filter(Boolean)
    .slice(0, 12);
}

export async function PATCH(request: Request) {
  const currentUser = await getCurrentUser();
  if (!currentUser) return Response.json({ error: "Sign in to update your profile." }, { status: 401 });

  const payload = await request.json().catch(() => null);
  const name = typeof payload?.name === "string" ? payload.name.trim().slice(0, 80) : currentUser.name;
  const headline = typeof payload?.headline === "string" ? payload.headline.trim().slice(0, 180) : currentUser.headline;
  const bio = typeof payload?.bio === "string" ? payload.bio.trim().slice(0, 600) : currentUser.bio;
  const location = typeof payload?.location === "string" ? payload.location.trim().slice(0, 120) : currentUser.location;
  if (name.length < 2) return Response.json({ error: "Your name must be at least 2 characters." }, { status: 400 });

  const [updated] = await db
    .update(users)
    .set({
      name,
      headline,
      bio,
      location,
      skills: cleanList(payload?.skills) ?? currentUser.skills,
      interests: cleanList(payload?.interests) ?? currentUser.interests,
    })
    .where(eq(users.id, currentUser.id))
    .returning({
      id: users.id,
      name: users.name,
      email: users.email,
      headline: users.headline,
      bio: users.bio,
      location: users.location,
      skills: users.skills,
      interests: users.interests,
      verified: users.verified,
      contributionScore: users.contributionScore,
      createdAt: users.createdAt,
    });

  return Response.json({ user: updated });
}
