import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

type RouteContext = { params: Promise<{ id: string }> };

function cleanSkills(value: unknown) {
  if (!Array.isArray(value)) return [];
  return value.filter((skill): skill is string => typeof skill === "string").map((skill) => skill.trim().slice(0, 48)).filter(Boolean).slice(0, 8);
}

export async function PATCH(request: Request, context: RouteContext) {
  const currentUser = await getCurrentUser();
  if (!currentUser) return Response.json({ error: "Sign in to edit your project." }, { status: 401 });
  const { id } = await context.params;
  const payload = await request.json().catch(() => null);
  const title = typeof payload?.title === "string" ? payload.title.trim().slice(0, 160) : "";
  const description = typeof payload?.description === "string" ? payload.description.trim().slice(0, 2500) : "";
  const category = typeof payload?.category === "string" ? payload.category.trim().slice(0, 80) : "";
  const lookingFor = typeof payload?.lookingFor === "string" ? payload.lookingFor.trim().slice(0, 180) : "";
  if (title.length < 4 || description.length < 24 || !category || !lookingFor) {
    return Response.json({ error: "Complete each project field before saving." }, { status: 400 });
  }
  const [updated] = await db.update(projects).set({ title, description, category, lookingFor, skills: cleanSkills(payload?.skills) })
    .where(and(eq(projects.id, id), eq(projects.creatorId, currentUser.id))).returning();
  if (!updated) return Response.json({ error: "Project not found or you don’t have permission to edit it." }, { status: 404 });
  return Response.json({ project: updated });
}

export async function DELETE(_request: Request, context: RouteContext) {
  const currentUser = await getCurrentUser();
  if (!currentUser) return Response.json({ error: "Sign in to delete your project." }, { status: 401 });
  const { id } = await context.params;
  const [deleted] = await db.delete(projects).where(and(eq(projects.id, id), eq(projects.creatorId, currentUser.id))).returning({ id: projects.id });
  if (!deleted) return Response.json({ error: "Project not found or you don’t have permission to delete it." }, { status: 404 });
  return Response.json({ ok: true, id: deleted.id });
}
