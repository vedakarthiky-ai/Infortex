import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { projects, users } from "@/db/schema";
import { ensureSeedData } from "@/db/seed";
import { getCurrentUser } from "@/lib/auth";

function cleanSkills(value: unknown) {
  if (!Array.isArray(value)) return [];
  return value.filter((skill): skill is string => typeof skill === "string").map((skill) => skill.trim().slice(0, 48)).filter(Boolean).slice(0, 8);
}

export async function GET() {
  await ensureSeedData();
  const rows = await db.select({
    id: projects.id,
    creatorId: projects.creatorId,
    title: projects.title,
    description: projects.description,
    category: projects.category,
    lookingFor: projects.lookingFor,
    skills: projects.skills,
    status: projects.status,
    createdAt: projects.createdAt,
    creatorName: users.name,
    creatorHeadline: users.headline,
    creatorVerified: users.verified,
  }).from(projects).innerJoin(users, eq(projects.creatorId, users.id)).orderBy(desc(projects.createdAt)).limit(30);
  return Response.json({
    projects: rows.map((project) => ({
      ...project,
      creator: {
        id: project.creatorId,
        name: project.creatorName,
        headline: project.creatorHeadline,
        verified: project.creatorVerified,
      },
    })),
  });
}

export async function POST(request: Request) {
  const currentUser = await getCurrentUser();
  if (!currentUser) return Response.json({ error: "Sign in to share a project." }, { status: 401 });
  const payload = await request.json().catch(() => null);
  const title = typeof payload?.title === "string" ? payload.title.trim().slice(0, 160) : "";
  const description = typeof payload?.description === "string" ? payload.description.trim().slice(0, 2500) : "";
  const category = typeof payload?.category === "string" ? payload.category.trim().slice(0, 80) : "Open source";
  const lookingFor = typeof payload?.lookingFor === "string" ? payload.lookingFor.trim().slice(0, 180) : "Collaborators";
  if (title.length < 4 || description.length < 24) return Response.json({ error: "Give your project a title and a little more context." }, { status: 400 });

  const [created] = await db.insert(projects).values({
    creatorId: currentUser.id,
    title,
    description,
    category: category || "Open source",
    lookingFor: lookingFor || "Collaborators",
    skills: cleanSkills(payload?.skills),
  }).returning();
  return Response.json({
    project: {
      ...created,
      creator: { id: currentUser.id, name: currentUser.name, headline: currentUser.headline, verified: currentUser.verified },
    },
  }, { status: 201 });
}
