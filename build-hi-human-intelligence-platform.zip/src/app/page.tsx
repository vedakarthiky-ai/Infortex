"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";

type PageKey = "home" | "community" | "projects" | "mentors" | "rooms" | "library" | "challenges" | "saved" | "profile" | "settings" | "about" | "pricing" | "blog" | "contact";
type User = {
  id: string;
  name: string;
  email: string;
  headline: string;
  bio: string;
  location: string;
  skills: string[];
  interests: string[];
  verified: boolean;
  contributionScore: number;
  createdAt?: string;
};
type Person = { id: string; name: string; headline: string; verified: boolean; contributionScore?: number };
type Reply = {
  id: string;
  postId: string;
  body: string;
  createdAt: string;
  author: { id: string; name: string; headline: string };
};
type Post = {
  id: string;
  authorId: string;
  kind: string;
  title: string;
  body: string;
  community: string;
  tags: string[];
  likes: number;
  createdAt: string;
  likedByMe: boolean;
  author: Person;
  comments: Reply[];
};
type Project = {
  id: string;
  creatorId: string;
  title: string;
  description: string;
  category: string;
  lookingFor: string;
  skills: string[];
  status: string;
  createdAt: string;
  creator: Person;
};
type Toast = { text: string; kind: "success" | "error" };
type ModalState = "auth" | "post" | "project" | "profile" | null;

const communityNames = ["Technology", "Programming", "Engineering", "AI & people", "Business", "Fitness", "Art & design", "Photography", "Science", "Education", "Startups", "Gaming", "Books", "Career"];
const pageLabels: Record<PageKey, string> = {
  home: "Home", community: "Community", projects: "Projects", mentors: "Mentors", rooms: "Think rooms",
  library: "Experience library", challenges: "Challenges", saved: "Saved for later", profile: "Your profile", settings: "Settings", about: "About HI",
  pricing: "Pricing", blog: "Blog", contact: "Contact",
};
const mentorNotes: Record<string, { focus: string; note: string; color: string }> = {
  "Aisha Rahman": { focus: "Engineering careers", note: "Good at making the first step feel smaller.", color: "mint" },
  "Elena García": { focus: "Research & academia", note: "Ask about grad school, HCI, or teaching.", color: "lilac" },
  "Maya Chen": { focus: "Product design", note: "Portfolio reviews with kindness and clarity.", color: "peach" },
  "Theo Park": { focus: "Climate & startups", note: "From a research prototype to real people.", color: "blue" },
  "Malik Johnson": { focus: "Early-stage founders", note: "Honest notes from the messy middle.", color: "gold" },
};

async function api<T>(url: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  const response = await fetch(url, { ...init, headers, credentials: "same-origin" });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong. Please try again.");
  return data as T;
}

function Icon({ name, size = 18, className = "" }: { name: string; size?: number; className?: string }) {
  const glyphs: Record<string, ReactNode> = {
    home: <><path d="m3 10 9-7 9 7" /><path d="M5 9v11h14V9M9 20v-6h6v6" /></>,
    compass: <><circle cx="12" cy="12" r="9" /><path d="m15.5 8.5-2.2 4.8-4.8 2.2 2.2-4.8 4.8-2.2Z" /></>,
    folder: <><path d="M3 6.5A1.5 1.5 0 0 1 4.5 5H10l2 2h7.5A1.5 1.5 0 0 1 21 8.5v9a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 17.5Z" /></>,
    people: <><path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="10" cy="7" r="4" /><path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /></>,
    message: <><path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8Z" /></>,
    book: <><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5Z" /><path d="M4 5.5v16M8 7h8M8 11h8" /></>,
    spark: <><path d="m12 3 1.9 5.8L20 11l-6.1 2.2L12 19l-1.9-5.8L4 11l6.1-2.2L12 3Z" /><path d="m19 14 .9 2.1L22 17l-2.1.9L19 20l-.9-2.1L16 17l2.1-.9L19 14ZM5 3l.7 1.8L7.5 5.5l-1.8.7L5 8l-.7-1.8-1.8-.7 1.8-.7L5 3Z" /></>,
    bookmark: <><path d="M6 4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V21l-6-4-6 4Z" /></>,
    trophy: <><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0Z" /><path d="M7 6H4v2a4 4 0 0 0 4 4M17 6h3v2a4 4 0 0 1-4 4" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.7a8 8 0 0 1-1.5.9L16 20.5h-2.8l-.3-1.8a8 8 0 0 1-1.6-.6l-1.6.8-1.8-2.1 1.1-1.5a7 7 0 0 1-.2-1.8l-1.5-1 1.1-2.6 1.8.2c.4-.4.9-.8 1.4-1.1l.1-1.8 2.8-.5.7 1.7c.6.1 1.1.3 1.6.6l1.6-.8 1.8 2.1-1.1 1.5c.2.6.3 1.2.3 1.8Z" /></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" /></>,
    search: <><circle cx="10.8" cy="10.8" r="6.8" /><path d="m16 16 4 4" /></>,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    arrow: <><path d="M5 12h14M13 6l6 6-6 6" /></>,
    chevron: <><path d="m9 18 6-6-6-6" /></>,
    check: <><path d="m5 12 4 4L19 6" /></>,
    verified: <><path d="m12 3 2.2 1.3 2.6-.1.8 2.4 2 1.7-.8 2.5.8 2.5-2 1.7-.8 2.4-2.6-.1L12 21l-2.2-1.3-2.6.1-.8-2.4-2-1.7.8-2.5-.8-2.5 2-1.7.8-2.4 2.6.1Z" /><path d="m9 12 2 2 4-4" /></>,
    heart: <><path d="M20.8 8.6c0 5.3-8.8 10.2-8.8 10.2S3.2 13.9 3.2 8.6A4.6 4.6 0 0 1 12 6.8a4.6 4.6 0 0 1 8.8 1.8Z" /></>,
    edit: <><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z" /></>,
    trash: <><path d="M3 6h18M8 6V4h8v2m3 0-1 14H6L5 6m4 4v6m6-6v6" /></>,
    send: <><path d="m22 2-7 20-4-9-9-4Z" /><path d="M22 2 11 13" /></>,
    close: <><path d="m18 6-12 12M6 6l12 12" /></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    trend: <><path d="m3 17 6-6 4 4 8-9" /><path d="M15 6h6v6" /></>,
    globe: <><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" /></>,
    target: <><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1" /></>,
    lightbulb: <><path d="M9 18h6M10 22h4M8.2 14.5A7 7 0 1 1 15.8 14.5c-.9.7-1.4 1.5-1.6 2.5h-4.4c-.2-1-.7-1.8-1.6-2.5Z" /></>,
    layers: <><path d="m12 3 9 5-9 5-9-5Z" /><path d="m3 12 9 5 9-5M3 16l9 5 9-5" /></>,
    logout: <><path d="M10 17l5-5-5-5M15 12H3" /><path d="M12 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-6" /></>,
    pin: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>,
    dots: <><circle cx="5" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /></>,
    chat: <><path d="M21 12a8 8 0 0 1-8 8H5l-2 1 1-4a8 8 0 1 1 17-5Z" /><path d="M8 12h8M8 9h5" /></>,
    coffee: <><path d="M5 8h12v7a4 4 0 0 1-4 4H9a4 4 0 0 1-4-4Z" /><path d="M17 10h2a2 2 0 1 1 0 4h-2M8 4c-1 1 1 1.5 0 3M13 4c-1 1 1 1.5 0 3" /></>,
  };
  return <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{glyphs[name] ?? glyphs.spark}</svg>;
}

function Avatar({ name, size = "md", verified = false }: { name: string; size?: "sm" | "md" | "lg" | "xl"; verified?: boolean }) {
  const initials = name.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
  const palette = ["avatar-mint", "avatar-blue", "avatar-lilac", "avatar-peach", "avatar-gold"];
  const color = palette[(name.charCodeAt(0) + name.length) % palette.length];
  return <span className={`avatar avatar-${size} ${color}`} aria-label={name}>{initials}{verified && <span className="avatar-check"><Icon name="check" size={9} /></span>}</span>;
}

function RelativeTime({ value }: { value: string }) {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    const timeout = window.setTimeout(() => setNow(Date.now()), 0);
    const interval = window.setInterval(() => setNow(Date.now()), 60_000);
    return () => { window.clearTimeout(timeout); window.clearInterval(interval); };
  }, []);
  if (now === null) return <>recently</>;
  const diff = Math.max(0, now - new Date(value).getTime());
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return <>now</>;
  if (minutes < 60) return <>{minutes}m</>;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return <>{hours}h</>;
  const days = Math.floor(hours / 24);
  if (days < 7) return <>{days}d</>;
  return <>{new Date(value).toLocaleDateString(undefined, { month: "short", day: "numeric" })}</>;
}

function Modal({ children, onClose, wide = false }: { children: ReactNode; onClose: () => void; wide?: boolean }) {
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <section className={`modal ${wide ? "modal-wide" : ""}`} role="dialog" aria-modal="true">{children}</section>
  </div>;
}

function AuthDialog({ mode, setMode, onClose, onSuccess }: { mode: "login" | "register"; setMode: (mode: "login" | "register") => void; onClose: () => void; onSuccess: (user: User) => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [ageConfirmed, setAgeConfirmed] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const signIn = async (selectedMode: "login" | "register", values = { name, email, password, ageConfirmed }) => {
    setError("");
    setBusy(true);
    try {
      const result = await api<{ user: User }>(`/api/auth/${selectedMode}`, {
        method: "POST",
        body: JSON.stringify({ ...values, ageConfirmed: selectedMode === "register" ? values.ageConfirmed : undefined }),
      });
      onSuccess(result.user);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Please try again.");
    } finally {
      setBusy(false);
    }
  };

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    void signIn(mode);
  };

  return <Modal onClose={onClose}>
    <div className="auth-topline"><span className="brand-mark brand-mark-small">h<span>i</span></span><button className="icon-button" aria-label="Close" onClick={onClose}><Icon name="close" /></button></div>
    <div className="auth-heading"><span className="eyebrow">A MORE HUMAN INTERNET</span><h2>{mode === "login" ? "Good to see you." : "Find your people."}</h2><p>{mode === "login" ? "Pick up where your curiosity left off." : "Join a network built on what we learn from each other."}</p></div>
    <form className="form-stack" onSubmit={submit}>
      {mode === "register" && <label className="field-label">Your name<input className="text-input" autoComplete="name" required minLength={2} maxLength={80} value={name} onChange={(event) => setName(event.target.value)} placeholder="How should we call you?" /></label>}
      <label className="field-label">Email address<input className="text-input" type="email" autoComplete="email" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@example.com" /></label>
      <label className="field-label">Password<input className="text-input" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} minLength={8} required value={password} onChange={(event) => setPassword(event.target.value)} placeholder="At least 8 characters" /></label>
      {mode === "register" && <label className="age-check"><input type="checkbox" checked={ageConfirmed} onChange={(event) => setAgeConfirmed(event.target.checked)} /><span>I confirm I’m 18 or older and agree to HI’s community guidelines.</span></label>}
      {error && <p className="form-error" role="alert">{error}</p>}
      <button className="btn btn-primary btn-full" disabled={busy || (mode === "register" && !ageConfirmed)}>{busy ? <span className="button-spinner" /> : null}{mode === "login" ? "Sign in" : "Create your account"}<Icon name="arrow" size={16} /></button>
    </form>
    <div className="auth-divider"><span>or try the demo</span></div>
    <button className="btn btn-secondary btn-full demo-button" disabled={busy} onClick={() => void signIn("login", { name: "", email: "maya@hi.community", password: "humanfirst", ageConfirmed: true })}><Avatar name="Maya Chen" size="sm" /> Explore as Maya Chen <span className="demo-note">demo account</span></button>
    <p className="auth-switch">{mode === "login" ? "New to HI?" : "Already part of HI?"} <button onClick={() => { setError(""); setMode(mode === "login" ? "register" : "login"); }}> {mode === "login" ? "Create an account" : "Sign in"}</button></p>
    <p className="age-note"><Icon name="globe" size={13} /> An 18+ community for curious people everywhere.</p>
  </Modal>;
}

function PostEditor({ post, onClose, onSubmit }: { post: Post | null; onClose: () => void; onSubmit: (payload: { title: string; body: string; community: string; kind: string; tags: string[] }) => Promise<void> }) {
  const [title, setTitle] = useState(post?.title ?? "");
  const [body, setBody] = useState(post?.body ?? "");
  const [community, setCommunity] = useState(post?.community ?? "Technology");
  const [kind, setKind] = useState(post?.kind ?? "discussion");
  const [tags, setTags] = useState(post?.tags.join(", ") ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setBusy(true); setError("");
    try { await onSubmit({ title, body, community, kind, tags: tags.split(",").map((tag) => tag.trim()).filter(Boolean) }); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Couldn’t save your post."); }
    finally { setBusy(false); }
  };
  return <Modal onClose={onClose} wide>
    <div className="modal-header"><div><span className="eyebrow">YOUR VOICE MATTERS</span><h2>{post ? "Edit your post" : "Start a conversation"}</h2><p>Share what you’ve learned, ask what you’re wondering, or bring an idea to life.</p></div><button className="icon-button" onClick={onClose} aria-label="Close"><Icon name="close" /></button></div>
    <form className="form-stack" onSubmit={submit}>
      <div className="form-row"><label className="field-label">Post type<select className="text-input" value={kind} onChange={(event) => setKind(event.target.value)}><option value="discussion">Discussion</option><option value="question">Question</option><option value="experience">Experience</option><option value="idea">Idea</option></select></label><label className="field-label">Community<select className="text-input" value={community} onChange={(event) => setCommunity(event.target.value)}>{communityNames.map((name) => <option key={name}>{name}</option>)}</select></label></div>
      <label className="field-label">Give it a thoughtful title<input className="text-input" required minLength={5} maxLength={180} value={title} onChange={(event) => setTitle(event.target.value)} placeholder="What would you like to explore?" /></label>
      <label className="field-label">Your perspective<textarea className="text-input text-area" required minLength={12} maxLength={4000} rows={5} value={body} onChange={(event) => setBody(event.target.value)} placeholder="A little context helps the right people find you…" /></label>
      <label className="field-label">Topics <span className="optional-note">separate with commas</span><input className="text-input" value={tags} onChange={(event) => setTags(event.target.value)} placeholder="Career, first job, advice" /></label>
      {error && <p className="form-error" role="alert">{error}</p>}
      <div className="modal-actions"><span className="form-footnote"><Icon name="verified" size={15} /> Every answer comes from a real person.</span><button className="btn btn-primary" disabled={busy}>{busy ? <span className="button-spinner" /> : null}{post ? "Save changes" : "Publish to HI"}<Icon name="arrow" size={16} /></button></div>
    </form>
  </Modal>;
}

function ProjectEditor({ project, onClose, onSubmit }: { project: Project | null; onClose: () => void; onSubmit: (payload: { title: string; description: string; category: string; lookingFor: string; skills: string[] }) => Promise<void> }) {
  const [title, setTitle] = useState(project?.title ?? "");
  const [description, setDescription] = useState(project?.description ?? "");
  const [category, setCategory] = useState(project?.category ?? "Open source");
  const [lookingFor, setLookingFor] = useState(project?.lookingFor ?? "");
  const [skills, setSkills] = useState(project?.skills.join(", ") ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setBusy(true); setError("");
    try { await onSubmit({ title, description, category, lookingFor, skills: skills.split(",").map((skill) => skill.trim()).filter(Boolean) }); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Couldn’t save this project."); }
    finally { setBusy(false); }
  };
  return <Modal onClose={onClose} wide>
    <div className="modal-header"><div><span className="eyebrow">GOOD THINGS ARE BUILT TOGETHER</span><h2>{project ? "Edit project" : "Find your collaborators"}</h2><p>Make room for the people who will help this idea become real.</p></div><button className="icon-button" onClick={onClose} aria-label="Close"><Icon name="close" /></button></div>
    <form className="form-stack" onSubmit={submit}>
      <label className="field-label">Project name<input className="text-input" required minLength={4} maxLength={160} value={title} onChange={(event) => setTitle(event.target.value)} placeholder="A name people will remember" /></label>
      <label className="field-label">What are you building?<textarea className="text-input text-area" required minLength={24} maxLength={2500} rows={4} value={description} onChange={(event) => setDescription(event.target.value)} placeholder="What problem are you working on, and why does it matter?" /></label>
      <div className="form-row"><label className="field-label">Category<input className="text-input" value={category} onChange={(event) => setCategory(event.target.value)} placeholder="e.g. Climate & community" /></label><label className="field-label">Who would help?<input className="text-input" value={lookingFor} onChange={(event) => setLookingFor(event.target.value)} placeholder="e.g. Designers, researchers" /></label></div>
      <label className="field-label">Skills & topics <span className="optional-note">separate with commas</span><input className="text-input" value={skills} onChange={(event) => setSkills(event.target.value)} placeholder="React, user research, storytelling" /></label>
      {error && <p className="form-error" role="alert">{error}</p>}
      <div className="modal-actions"><span className="form-footnote"><Icon name="people" size={15} /> No follower counts. Just good work.</span><button className="btn btn-primary" disabled={busy}>{busy ? <span className="button-spinner" /> : null}{project ? "Save changes" : "Share project"}<Icon name="arrow" size={16} /></button></div>
    </form>
  </Modal>;
}

function ProfileEditor({ user, onClose, onSubmit }: { user: User; onClose: () => void; onSubmit: (payload: Partial<User>) => Promise<void> }) {
  const [name, setName] = useState(user.name);
  const [headline, setHeadline] = useState(user.headline);
  const [bio, setBio] = useState(user.bio);
  const [location, setLocation] = useState(user.location);
  const [skills, setSkills] = useState(user.skills.join(", "));
  const [interests, setInterests] = useState(user.interests.join(", "));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setBusy(true); setError("");
    try { await onSubmit({ name, headline, bio, location, skills: skills.split(",").map((item) => item.trim()).filter(Boolean), interests: interests.split(",").map((item) => item.trim()).filter(Boolean) }); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Couldn’t update your profile."); }
    finally { setBusy(false); }
  };
  return <Modal onClose={onClose} wide>
    <div className="modal-header"><div><span className="eyebrow">A LITTLE MORE YOU</span><h2>Edit your profile</h2><p>Help the right people find a reason to say hello.</p></div><button className="icon-button" onClick={onClose} aria-label="Close"><Icon name="close" /></button></div>
    <form className="form-stack" onSubmit={submit}>
      <div className="form-row"><label className="field-label">Name<input className="text-input" required minLength={2} maxLength={80} value={name} onChange={(event) => setName(event.target.value)} /></label><label className="field-label">What you do<input className="text-input" maxLength={180} value={headline} onChange={(event) => setHeadline(event.target.value)} placeholder="Designer, mentor, lifelong learner" /></label></div>
      <label className="field-label">A short introduction<textarea className="text-input text-area" rows={3} maxLength={600} value={bio} onChange={(event) => setBio(event.target.value)} placeholder="The kind of things you love helping with…" /></label>
      <label className="field-label">Location<input className="text-input" maxLength={120} value={location} onChange={(event) => setLocation(event.target.value)} placeholder="City, country (optional)" /></label>
      <div className="form-row"><label className="field-label">Skills <span className="optional-note">comma separated</span><input className="text-input" value={skills} onChange={(event) => setSkills(event.target.value)} placeholder="Research, design, JavaScript" /></label><label className="field-label">Interests <span className="optional-note">comma separated</span><input className="text-input" value={interests} onChange={(event) => setInterests(event.target.value)} placeholder="Books, climate, mentoring" /></label></div>
      {error && <p className="form-error" role="alert">{error}</p>}
      <div className="modal-actions"><span className="form-footnote"><Icon name="verified" size={15} /> Your profile is yours to shape.</span><button className="btn btn-primary" disabled={busy}>{busy ? <span className="button-spinner" /> : null}Save profile<Icon name="arrow" size={16} /></button></div>
    </form>
  </Modal>;
}

function PostCard({ post, currentUser, saved, onLike, onSave, onReply, onEdit, onDelete, onEditReply, onDeleteReply, onAuth }: {
  post: Post; currentUser: User | null; saved: boolean; onLike: (id: string) => void; onSave: (id: string) => void;
  onReply: (id: string, body: string) => Promise<void>; onEdit: (post: Post) => void; onDelete: (post: Post) => void;
  onEditReply: (reply: Reply, body: string) => Promise<void>; onDeleteReply: (reply: Reply) => void; onAuth: () => void;
}) {
  const [showReplies, setShowReplies] = useState(false);
  const [replyDraft, setReplyDraft] = useState("");
  const [replyBusy, setReplyBusy] = useState(false);
  const [editingReply, setEditingReply] = useState<string | null>(null);
  const [editingText, setEditingText] = useState("");
  const owned = currentUser?.id === post.authorId;
  const submitReply = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!currentUser) { onAuth(); return; }
    if (replyDraft.trim().length < 2) return;
    setReplyBusy(true);
    try { await onReply(post.id, replyDraft); setReplyDraft(""); setShowReplies(true); }
    finally { setReplyBusy(false); }
  };
  const kindLabel = post.kind === "question" ? "Question" : post.kind === "experience" ? "Experience" : post.kind === "idea" ? "Idea" : "Discussion";
  return <article className="post-card">
    <div className="post-topline"><div className="post-author"><Avatar name={post.author.name} size="md" verified={post.author.verified} /><div className="author-copy"><div className="author-name-row"><strong>{post.author.name}</strong>{post.author.verified && <span className="verified-label"><Icon name="verified" size={13} /> Verified</span>}<span className="post-dot">·</span><span className="post-time"><RelativeTime value={post.createdAt} /></span></div><span className="author-headline">{post.author.headline}</span></div></div>
      <div className="post-tools"><span className={`kind-label kind-${post.kind}`}>{kindLabel}</span>{owned && <div className="own-tools"><button className="tiny-icon" aria-label="Edit post" title="Edit post" onClick={() => onEdit(post)}><Icon name="edit" size={15} /></button><button className="tiny-icon" aria-label="Delete post" title="Delete post" onClick={() => onDelete(post)}><Icon name="trash" size={15} /></button></div>}</div>
    </div>
    <button className="post-community" onClick={() => window.dispatchEvent(new CustomEvent("hi:community", { detail: post.community }))}><span className="community-spark">✳</span> {post.community}</button>
    <h3 className="post-title">{post.title}</h3>
    <p className="post-body">{post.body}</p>
    {post.tags.length > 0 && <div className="tag-row">{post.tags.map((tag) => <span className="tag" key={tag}>#{tag}</span>)}</div>}
    <div className="post-footer"><div className="post-actions"><button className={`post-action ${post.likedByMe ? "is-liked" : ""}`} onClick={() => onLike(post.id)} aria-label={post.likedByMe ? "Remove appreciation" : "Appreciate this post"}><Icon name="heart" size={16} /><span>{post.likes || "Appreciate"}</span></button><button className={`post-action ${showReplies ? "action-active" : ""}`} onClick={() => setShowReplies(!showReplies)}><Icon name="chat" size={16} /><span>{post.comments.length ? `${post.comments.length} ${post.comments.length === 1 ? "reply" : "replies"}` : "Add perspective"}</span></button></div><button className={`post-action save-action ${saved ? "is-saved" : ""}`} onClick={() => onSave(post.id)} aria-label={saved ? "Remove saved post" : "Save post"}><Icon name="bookmark" size={16} /><span>{saved ? "Saved" : "Save"}</span></button></div>
    {showReplies && <div className="reply-panel"><div className="reply-list">{post.comments.map((reply) => <ReplyItem key={reply.id} reply={reply} currentUser={currentUser} editing={editingReply === reply.id} editingText={editingText} setEditingText={setEditingText} onBeginEdit={() => { setEditingReply(reply.id); setEditingText(reply.body); }} onCancelEdit={() => setEditingReply(null)} onSaveEdit={async () => { await onEditReply(reply, editingText); setEditingReply(null); }} onDelete={() => onDeleteReply(reply)} />)}</div><form className="reply-form" onSubmit={submitReply}><Avatar name={currentUser?.name ?? "You"} size="sm" /><input value={replyDraft} onChange={(event) => setReplyDraft(event.target.value)} onFocus={() => { if (!currentUser) onAuth(); }} placeholder={currentUser ? "Add a thoughtful perspective…" : "Sign in to join the conversation…"} aria-label="Write a reply" /><button className="reply-send" disabled={replyBusy || replyDraft.trim().length < 2} aria-label="Send reply"><Icon name="send" size={16} /></button></form></div>}
  </article>;
}

function ReplyItem({ reply, currentUser, editing, editingText, setEditingText, onBeginEdit, onCancelEdit, onSaveEdit, onDelete }: {
  reply: Reply; currentUser: User | null; editing: boolean; editingText: string; setEditingText: (text: string) => void; onBeginEdit: () => void; onCancelEdit: () => void; onSaveEdit: () => void; onDelete: () => void;
}) {
  const own = currentUser?.id === reply.author.id;
  return <div className="reply-item"><Avatar name={reply.author.name} size="sm" /><div className="reply-content"><div className="reply-meta"><strong>{reply.author.name}</strong><span>{reply.author.headline}</span></div>{editing ? <div className="reply-edit"><input className="text-input" value={editingText} onChange={(event) => setEditingText(event.target.value)} /><button className="text-link" onClick={onSaveEdit}>Save</button><button className="text-link muted-link" onClick={onCancelEdit}>Cancel</button></div> : <p>{reply.body}</p>}</div>{own && !editing && <div className="reply-tools"><button className="tiny-icon" title="Edit reply" aria-label="Edit reply" onClick={onBeginEdit}><Icon name="edit" size={13} /></button><button className="tiny-icon" title="Delete reply" aria-label="Delete reply" onClick={onDelete}><Icon name="trash" size={13} /></button></div>}</div>;
}

function ProjectCard({ project, currentUser, onEdit, onDelete, onConnect }: { project: Project; currentUser: User | null; onEdit: (project: Project) => void; onDelete: (project: Project) => void; onConnect: () => void }) {
  const owned = currentUser?.id === project.creatorId;
  const theme = project.category.toLowerCase().includes("climate") ? "project-green" : project.category.toLowerCase().includes("design") ? "project-purple" : project.category.toLowerCase().includes("open") ? "project-blue" : "project-orange";
  return <article className="project-card"><div className={`project-art ${theme}`}><span className="project-art-orbit orbit-one" /><span className="project-art-orbit orbit-two" /><span className="project-art-symbol"><Icon name={project.category.toLowerCase().includes("design") ? "spark" : project.category.toLowerCase().includes("climate") ? "globe" : "layers"} size={23} /></span><span className="project-status"><span /> {project.status}</span></div>
    <div className="project-card-body"><div className="project-card-top"><span className="eyebrow">{project.category}</span>{owned && <div className="own-tools"><button className="tiny-icon" onClick={() => onEdit(project)} aria-label="Edit project"><Icon name="edit" size={15} /></button><button className="tiny-icon" onClick={() => onDelete(project)} aria-label="Delete project"><Icon name="trash" size={15} /></button></div>}</div><h3>{project.title}</h3><p>{project.description}</p><div className="project-skills">{project.skills.map((skill) => <span className="tag" key={skill}>{skill}</span>)}</div><div className="project-foot"><div className="project-owner"><Avatar name={project.creator.name} size="sm" verified={project.creator.verified} /><div><strong>{project.creator.name}</strong><span>{project.creator.headline}</span></div></div><button className="btn btn-small btn-secondary" onClick={owned ? () => onEdit(project) : onConnect}>{owned ? "Your project" : "Meet the team"}<Icon name="arrow" size={14} /></button></div><div className="looking-for"><Icon name="people" size={14} /><span>Looking for <strong>{project.lookingFor}</strong></span></div></div>
  </article>;
}

function EmptyState({ icon, title, detail, action, onAction }: { icon: string; title: string; detail: string; action?: string; onAction?: () => void }) {
  return <div className="empty-state"><span className="empty-icon"><Icon name={icon} size={22} /></span><h3>{title}</h3><p>{detail}</p>{action && onAction && <button className="btn btn-secondary btn-small" onClick={onAction}>{action}<Icon name="arrow" size={14} /></button>}</div>;
}

export default function HomePage() {
  const [page, setPage] = useState<PageKey>("home");
  const [user, setUser] = useState<User | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [savedIds, setSavedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<ModalState>(null);
  const [authMode, setAuthMode] = useState<"login" | "register">("register");
  const [editingPost, setEditingPost] = useState<Post | null>(null);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [query, setQuery] = useState("");
  const [feedFilter, setFeedFilter] = useState("For you");
  const [projectFilter, setProjectFilter] = useState("All projects");
  const [joinedRooms, setJoinedRooms] = useState<string[]>([]);
  const [challengeVote, setChallengeVote] = useState<string | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [toast, setToast] = useState<Toast | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const notify = useCallback((text: string, kind: Toast["kind"] = "success") => {
    setToast({ text, kind });
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 3400);
  }, []);

  const refreshPosts = useCallback(async () => {
    const result = await api<{ posts: Post[] }>("/api/posts");
    setPosts(result.posts);
  }, []);

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const [postData, projectData, sessionData, bookmarkData] = await Promise.all([
          api<{ posts: Post[] }>("/api/posts"),
          api<{ projects: Project[] }>("/api/projects"),
          api<{ user: User | null }>("/api/auth/me"),
          api<{ ids: string[] }>("/api/bookmarks"),
        ]);
        if (!active) return;
        setPosts(postData.posts);
        setProjects(projectData.projects);
        setUser(sessionData.user);
        setSavedIds(bookmarkData.ids);
      } catch (error) {
        if (active) notify(error instanceof Error ? error.message : "The community could not load.", "error");
      } finally {
        if (active) setLoading(false);
      }
    };
    void load();
    const onCommunity = (event: Event) => {
      const detail = (event as CustomEvent<string>).detail;
      setPage("community"); setQuery(detail); setFeedFilter("For you");
    };
    window.addEventListener("hi:community", onCommunity);
    return () => { active = false; window.removeEventListener("hi:community", onCommunity); };
  }, [notify]);

  useEffect(() => () => { if (toastTimer.current) clearTimeout(toastTimer.current); }, []);

  useEffect(() => {
    const focusSearch = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        document.getElementById("hi-global-search")?.focus();
      }
    };
    window.addEventListener("keydown", focusSearch);
    return () => window.removeEventListener("keydown", focusSearch);
  }, []);

  const openAuth = useCallback((mode: "login" | "register" = "register") => {
    setAuthMode(mode); setModal("auth"); setMobileOpen(false);
  }, []);

  const finishAuth = async (nextUser: User) => {
    setUser(nextUser); setModal(null); setPage("home");
    try {
      const [postData, bookmarkData] = await Promise.all([api<{ posts: Post[] }>("/api/posts"), api<{ ids: string[] }>("/api/bookmarks")]);
      setPosts(postData.posts); setSavedIds(bookmarkData.ids);
    } catch { /* Existing view remains usable if a refresh is temporarily unavailable. */ }
    notify(`Welcome to HI, ${nextUser.name.split(" ")[0]}.`);
  };

  const handlePostSubmit = async (payload: { title: string; body: string; community: string; kind: string; tags: string[] }) => {
    if (!user) throw new Error("Sign in to publish a post.");
    if (editingPost) {
      const result = await api<{ post: Partial<Post> }>(`/api/posts/${editingPost.id}`, { method: "PATCH", body: JSON.stringify(payload) });
      setPosts((current) => current.map((post) => post.id === editingPost.id ? { ...post, ...result.post, author: post.author, comments: post.comments } as Post : post));
      setModal(null); setEditingPost(null); notify("Your changes are live."); return;
    }
    const tempId = `pending-${Date.now()}`;
    const optimistic: Post = { id: tempId, authorId: user.id, ...payload, likes: 0, createdAt: new Date().toISOString(), likedByMe: false, author: { id: user.id, name: user.name, headline: user.headline, verified: user.verified, contributionScore: user.contributionScore }, comments: [] };
    setPosts((current) => [optimistic, ...current]); setModal(null); setPage("community");
    try {
      const result = await api<{ post: Post }>("/api/posts", { method: "POST", body: JSON.stringify(payload) });
      setPosts((current) => current.map((post) => post.id === tempId ? result.post : post)); notify("Your conversation is out in the world.");
    } catch (error) { setPosts((current) => current.filter((post) => post.id !== tempId)); throw error; }
  };

  const handleProjectSubmit = async (payload: { title: string; description: string; category: string; lookingFor: string; skills: string[] }) => {
    if (!user) throw new Error("Sign in to share a project.");
    if (editingProject) {
      const result = await api<{ project: Partial<Project> }>(`/api/projects/${editingProject.id}`, { method: "PATCH", body: JSON.stringify(payload) });
      setProjects((current) => current.map((project) => project.id === editingProject.id ? { ...project, ...result.project, creator: project.creator } as Project : project));
      setModal(null); setEditingProject(null); notify("Project details updated."); return;
    }
    const tempId = `pending-${Date.now()}`;
    const optimistic: Project = { id: tempId, creatorId: user.id, ...payload, status: "Open to collaborators", createdAt: new Date().toISOString(), creator: { id: user.id, name: user.name, headline: user.headline, verified: user.verified } };
    setProjects((current) => [optimistic, ...current]); setModal(null); setPage("projects");
    try {
      const result = await api<{ project: Project }>("/api/projects", { method: "POST", body: JSON.stringify(payload) });
      setProjects((current) => current.map((project) => project.id === tempId ? result.project : project)); notify("Your project is open for collaboration.");
    } catch (error) { setProjects((current) => current.filter((project) => project.id !== tempId)); throw error; }
  };

  const handleProfileSubmit = async (payload: Partial<User>) => {
    const result = await api<{ user: User }>("/api/profile", { method: "PATCH", body: JSON.stringify(payload) });
    setUser(result.user); setModal(null); notify("Your profile has been updated.");
  };

  const handleLike = async (id: string) => {
    if (!user) { openAuth("login"); return; }
    const prior = posts.find((post) => post.id === id);
    if (!prior) return;
    const nextLiked = !prior.likedByMe;
    setPosts((current) => current.map((post) => post.id === id ? { ...post, likedByMe: nextLiked, likes: Math.max(0, post.likes + (nextLiked ? 1 : -1)) } : post));
    try {
      const result = await api<{ liked: boolean; likes: number }>(`/api/posts/${id}/like`, { method: "POST" });
      setPosts((current) => current.map((post) => post.id === id ? { ...post, likedByMe: result.liked, likes: result.likes } : post));
    } catch (error) {
      setPosts((current) => current.map((post) => post.id === id ? { ...post, likedByMe: prior.likedByMe, likes: prior.likes } : post));
      notify(error instanceof Error ? error.message : "Couldn’t save that appreciation.", "error");
    }
  };

  const handleSave = async (id: string) => {
    if (!user) { openAuth("login"); return; }
    const wasSaved = savedIds.includes(id);
    setSavedIds((current) => wasSaved ? current.filter((item) => item !== id) : [...current, id]);
    try {
      const result = await api<{ saved: boolean }>("/api/bookmarks", { method: "POST", body: JSON.stringify({ postId: id }) });
      setSavedIds((current) => result.saved ? Array.from(new Set([...current, id])) : current.filter((item) => item !== id));
    } catch (error) {
      setSavedIds((current) => wasSaved ? Array.from(new Set([...current, id])) : current.filter((item) => item !== id));
      notify(error instanceof Error ? error.message : "Couldn’t update your saved posts.", "error");
    }
  };

  const handleReply = async (postId: string, body: string) => {
    const result = await api<{ comment: Reply }>(`/api/posts/${postId}/comments`, { method: "POST", body: JSON.stringify({ body }) });
    setPosts((current) => current.map((post) => post.id === postId ? { ...post, comments: [...post.comments, result.comment] } : post));
  };

  const handleEditReply = async (reply: Reply, body: string) => {
    const result = await api<{ comment: Reply }>(`/api/comments/${reply.id}`, { method: "PATCH", body: JSON.stringify({ body }) });
    setPosts((current) => current.map((post) => ({ ...post, comments: post.comments.map((item) => item.id === reply.id ? { ...item, ...result.comment, author: item.author } : item) })));
    notify("Reply updated.");
  };

  const handleDeleteReply = async (reply: Reply) => {
    if (!window.confirm("Delete this reply?")) return;
    const snapshot = posts;
    setPosts((current) => current.map((post) => ({ ...post, comments: post.comments.filter((item) => item.id !== reply.id) })));
    try { await api(`/api/comments/${reply.id}`, { method: "DELETE" }); }
    catch (error) { setPosts(snapshot); notify(error instanceof Error ? error.message : "Couldn’t delete that reply.", "error"); }
  };

  const handleDeletePost = async (post: Post) => {
    if (!window.confirm("Delete this conversation? This can’t be undone.")) return;
    const snapshot = posts;
    setPosts((current) => current.filter((item) => item.id !== post.id)); setSavedIds((current) => current.filter((id) => id !== post.id));
    try { await api(`/api/posts/${post.id}`, { method: "DELETE" }); notify("Conversation deleted."); }
    catch (error) { setPosts(snapshot); notify(error instanceof Error ? error.message : "Couldn’t delete that post.", "error"); }
  };

  const handleDeleteProject = async (project: Project) => {
    if (!window.confirm("Remove this project from the board?")) return;
    const snapshot = projects;
    setProjects((current) => current.filter((item) => item.id !== project.id));
    try { await api(`/api/projects/${project.id}`, { method: "DELETE" }); notify("Project removed."); }
    catch (error) { setProjects(snapshot); notify(error instanceof Error ? error.message : "Couldn’t delete that project.", "error"); }
  };

  const logout = async () => {
    try { await api("/api/auth/logout", { method: "POST" }); }
    finally { setUser(null); setSavedIds([]); setPosts((current) => current.map((post) => ({ ...post, likedByMe: false }))); setPage("home"); notify("You’re signed out. See you again soon."); }
  };

  const filteredPosts = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return posts.filter((post) => {
      if (page === "saved" && !savedIds.includes(post.id)) return false;
      if (page === "library" && post.kind !== "experience") return false;
      if (page === "community" && feedFilter !== "For you" && post.kind !== feedFilter.toLowerCase().replace(/s$/, "")) {
        const expected = feedFilter === "Experiences" ? "experience" : feedFilter === "Questions" ? "question" : feedFilter === "Ideas" ? "idea" : "discussion";
        if (feedFilter !== "Discussions" || post.kind !== expected) return false;
      }
      if (normalized && ![post.title, post.body, post.community, ...post.tags, post.author.name].join(" ").toLowerCase().includes(normalized)) return false;
      return true;
    });
  }, [posts, query, page, savedIds, feedFilter]);

  const visiblePosts = page === "home" ? filteredPosts.slice(0, 3) : filteredPosts;
  const filteredProjects = projects.filter((project) => projectFilter !== "My projects" || project.creatorId === user?.id);
  const allPeople = useMemo(() => {
    const seen = new Map<string, Person>();
    posts.forEach((post) => seen.set(post.author.id, post.author));
    projects.forEach((project) => seen.set(project.creator.id, project.creator));
    return Array.from(seen.values());
  }, [posts, projects]);
  const mentors = allPeople.filter((person) => person.verified).slice(0, 4);
  const communityCounts = useMemo(() => communityNames.slice(0, 6).map((name, index) => ({ name, count: [2840, 1920, 1640, 1270, 980, 750][index] })), []);

  const choosePage = (nextPage: PageKey) => { setPage(nextPage); setQuery(""); setMobileOpen(false); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const createPost = () => { if (!user) { openAuth(); return; } setEditingPost(null); setModal("post"); };
  const createProject = () => { if (!user) { openAuth(); return; } setEditingProject(null); setModal("project"); };
  const editPost = (post: Post) => { setEditingPost(post); setModal("post"); };
  const editProject = (project: Project) => { setEditingProject(project); setModal("project"); };
  const onConnectProject = () => user ? notify("We’ve sent the project host a connection request.") : openAuth();

  const renderPost = (post: Post) => <PostCard key={post.id} post={post} currentUser={user} saved={savedIds.includes(post.id)} onLike={(id) => void handleLike(id)} onSave={(id) => void handleSave(id)} onReply={handleReply} onEdit={editPost} onDelete={(item) => void handleDeletePost(item)} onEditReply={handleEditReply} onDeleteReply={(reply) => void handleDeleteReply(reply)} onAuth={() => openAuth("login")} />;

  return <main className="app-shell">
    {mobileOpen && <button className="mobile-scrim" aria-label="Close navigation" onClick={() => setMobileOpen(false)} />}
    <aside className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}>
      <button className="brand-lockup" onClick={() => choosePage("home")} aria-label="HI home"><span className="brand-mark">h<span>i</span></span><span className="brand-copy"><strong>HI</strong><small>HUMAN INTELLIGENCE</small></span></button>
      <div className="sidebar-inner">
        <div className="nav-section"><span className="nav-caption">YOUR SPACE</span>
          <NavButton icon="home" label="Home" pageKey="home" active={page} onClick={choosePage} badge="" />
          <NavButton icon="compass" label="Community" pageKey="community" active={page} onClick={choosePage} badge="" />
          <NavButton icon="folder" label="Projects" pageKey="projects" active={page} onClick={choosePage} badge="04" />
          <NavButton icon="people" label="Mentors" pageKey="mentors" active={page} onClick={choosePage} badge="" />
        </div>
        <div className="nav-section"><span className="nav-caption">EXPLORE</span>
          <NavButton icon="message" label="Think rooms" pageKey="rooms" active={page} onClick={choosePage} badge={<span className="live-indicator" />} />
          <NavButton icon="book" label="Experience library" pageKey="library" active={page} onClick={choosePage} badge="" />
          <NavButton icon="spark" label="Challenges" pageKey="challenges" active={page} onClick={choosePage} badge="NEW" />
          <NavButton icon="bookmark" label="Saved" pageKey="saved" active={page} onClick={choosePage} badge="" />
        </div>
        <div className="nav-section account-nav"><span className="nav-caption">ACCOUNT</span>
          <NavButton icon="people" label="Profile" pageKey="profile" active={page} onClick={choosePage} badge="" />
          <NavButton icon="settings" label="Settings" pageKey="settings" active={page} onClick={choosePage} badge="" />
        </div>
        <div className="nav-section hi-nav"><span className="nav-caption">HI</span>
          <NavButton icon="lightbulb" label="About HI" pageKey="about" active={page} onClick={choosePage} badge="" />
          <NavButton icon="layers" label="Pricing" pageKey="pricing" active={page} onClick={choosePage} badge="" />
          <NavButton icon="book" label="Blog" pageKey="blog" active={page} onClick={choosePage} badge="" />
          <NavButton icon="message" label="Contact" pageKey="contact" active={page} onClick={choosePage} badge="" />
        </div>
        <div className="sidebar-communities"><div className="community-heading"><span className="nav-caption">YOUR COMMUNITIES</span><button className="tiny-icon" aria-label="Discover communities" onClick={() => choosePage("community")}><Icon name="plus" size={14} /></button></div>{communityNames.slice(0, 5).map((name, index) => <button className={`community-nav ${page === "community" && query === name ? "community-nav-active" : ""}`} key={name} onClick={() => { setPage("community"); setQuery(name); setFeedFilter("For you"); }}><span className={`community-dot community-dot-${index}`} />{name}</button>)}<button className="all-communities" onClick={() => choosePage("community")}>Explore all communities <Icon name="arrow" size={13} /></button></div>
      </div>
      <div className="sidebar-bottom">
        {!user && <div className="sidebar-invite"><div className="invite-icon"><Icon name="spark" size={16} /></div><strong>Make room for humans.</strong><p>Good questions find good people here.</p><button onClick={() => openAuth()}>Join HI <Icon name="arrow" size={13} /></button></div>}
        <button className="sidebar-profile" onClick={() => user ? choosePage("profile") : openAuth("login")}><Avatar name={user?.name ?? "Guest"} size="md" /><span className="sidebar-profile-copy"><strong>{user?.name ?? "Welcome, human"}</strong><small>{user ? `${user.contributionScore.toLocaleString()} contribution points` : "Sign in to personalize HI"}</small></span><Icon name="dots" size={17} className="profile-dots" /></button>
      </div>
    </aside>

    <section className="main-shell">
      <header className="topbar"><div className="topbar-left"><button className="mobile-menu icon-button" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Icon name="menu" /></button><div className="breadcrumbs"><span>Workspace</span><Icon name="chevron" size={13} /><strong>{pageLabels[page]}</strong></div></div><div className="topbar-actions"><label className="global-search"><Icon name="search" size={16} /><input id="hi-global-search" value={query} onChange={(event) => { setQuery(event.target.value); if (page === "home") setPage("community"); }} placeholder="Search people, ideas…" aria-label="Search HI" /><kbd>⌘ K</kbd></label><button className="top-icon-button" aria-label="Notifications" onClick={() => user ? notify("You’re all caught up. New conversations will find you here.") : openAuth("login")}><Icon name="bell" size={18} /><span className="notification-dot" /></button><span className="top-divider" />{user ? <button className="top-user" onClick={() => choosePage("profile")}><Avatar name={user.name} size="sm" verified={user.verified} /><span>{user.name.split(" ")[0]}</span></button> : <button className="sign-in-link" onClick={() => openAuth("login")}>Sign in</button>}</div></header>

      <div className="page-content">
        {page === "home" && <>
          <section className="hero-card"><div className="hero-noise" /><NetworkArt /><div className="hero-content"><div className="eyebrow hero-eyebrow"><span className="eyebrow-live" /> THE HUMAN INTELLIGENCE NETWORK</div><h1>Human<br /><span>Intelligence.</span></h1><p className="hero-lede">AI gives answers. Humans give experiences.<br className="desktop-break" /> Find your people, and figure it out together.</p><div className="hero-actions"><button className="btn btn-primary" onClick={() => user ? createPost() : openAuth()}>{user ? "Start a conversation" : "Join HI"}<Icon name="arrow" size={16} /></button><button className="btn btn-ghost" onClick={() => choosePage("community")}>Explore community <Icon name="chevron" size={15} /></button></div><div className="hero-proof"><div className="avatar-stack"><Avatar name="Aisha Rahman" size="sm" /><Avatar name="Maya Chen" size="sm" /><Avatar name="Theo Park" size="sm" /><Avatar name="Elena García" size="sm" /></div><span><strong>21,400+</strong> curious minds, in 86 countries</span></div></div><div className="hero-orbit"><div className="orbit-ring ring-a" /><div className="orbit-ring ring-b" /><span className="orbit-core">hi</span><span className="orbit-person person-a">M</span><span className="orbit-person person-b">A</span><span className="orbit-person person-c">T</span><span className="orbit-person person-d">E</span><div className="orbit-caption"><span className="live-indicator" /> real people, right now</div></div><div className="hero-bottom-line"><span>REAL PEOPLE. REAL INTELLIGENCE.</span><span>BUILT FOR WHAT MAKES US HUMAN <Icon name="arrow" size={13} /></span></div></section>

          <div className="home-intro-row"><div><span className="eyebrow">A DIFFERENT KIND OF INTERNET</span><h2>Some things are better<br className="desktop-break" /> figured out <em>together.</em></h2></div><p>When you need more than an answer. When you need a perspective, a sounding board, or someone who’s been there. That’s where HI begins.</p></div>

          <div className="home-grid"><div className="feed-column"><div className="section-heading-row"><div><span className="eyebrow">HAPPENING ON HI</span><h2>Conversations worth having</h2></div><button className="text-link" onClick={() => choosePage("community")}>View community <Icon name="arrow" size={14} /></button></div>
            <div className="compose-card"><Avatar name={user?.name ?? "You"} size="md" /><button onClick={createPost}>{user ? "What have you learned lately?" : "What would you like to figure out?"}</button><button className="compose-plus" onClick={createPost} aria-label="Create a post"><Icon name="plus" size={18} /></button></div>
            {loading ? <PostSkeletons /> : visiblePosts.length ? <div className="post-list">{visiblePosts.map(renderPost)}</div> : <EmptyState icon="message" title="A little quiet here" detail="Start a conversation and invite the right people in." action="Write the first post" onAction={createPost} />}
            <div className="home-why-card"><span className="why-card-icon"><Icon name="lightbulb" size={19} /></span><div><span className="eyebrow">WHY HI EXISTS</span><h3>Information is everywhere.<br />Understanding is a human thing.</h3><p>Real judgment, lived experience, empathy, and the details that only come from being there.</p><button className="text-link" onClick={() => choosePage("about")}>Our point of view <Icon name="arrow" size={14} /></button></div><div className="why-quote-mark">“</div></div>
          </div><aside className="home-rail"><div className="rail-card community-rail"><div className="rail-title"><div><span className="eyebrow">YOUR CORNER OF HI</span><h3>Find your people</h3></div><button className="tiny-icon" aria-label="Explore communities" onClick={() => choosePage("community")}><Icon name="arrow" size={15} /></button></div>{communityCounts.slice(0, 5).map((community, index) => <button className="community-row" key={community.name} onClick={() => { setPage("community"); setQuery(community.name); }}><span className={`community-tile tile-${index}`}>{community.name.slice(0, 1)}</span><span className="community-row-copy"><strong>{community.name}</strong><small>{community.count.toLocaleString()} curious minds</small></span><Icon name="chevron" size={15} /></button>)}<button className="rail-footer-link" onClick={() => choosePage("community")}>Explore 40+ communities <Icon name="arrow" size={13} /></button></div>
            <div className="rail-card mentor-rail"><div className="rail-title"><div><span className="eyebrow">LEARN FROM SOMEONE</span><h3>Good humans to know</h3></div><button className="tiny-icon" aria-label="Browse mentors" onClick={() => choosePage("mentors")}><Icon name="arrow" size={15} /></button></div>{mentors.slice(0, 3).map((mentor) => <button className="mentor-row" key={mentor.id} onClick={() => choosePage("mentors")}><Avatar name={mentor.name} size="md" verified={mentor.verified} /><span className="mentor-row-copy"><strong>{mentor.name}</strong><small>{mentorNotes[mentor.name]?.focus ?? mentor.headline}</small></span><span className="mentor-online" title="Available to connect" /></button>)}<button className="rail-footer-link" onClick={() => choosePage("mentors")}>Meet the mentors <Icon name="arrow" size={13} /></button></div>
            <div className="rail-note"><Icon name="verified" size={16} /><p><strong>Human by design.</strong><br />Every answer on HI comes from a person with a point of view.</p></div>
          </aside></div>

          <section className="feature-section"><div className="section-heading-row"><div><span className="eyebrow">MADE FOR REAL HUMAN THINGS</span><h2>More than an answer.</h2></div><p>Technology should make it easier to find each other.<br />Here’s what we’re making possible.</p></div><div className="feature-grid"><FeatureCard icon="chat" number="01" title="Human discussions" text="Questions answered with context, care, and the kind of nuance a search bar can’t give you." /><FeatureCard icon="people" number="02" title="Mentors who get it" text="Learn directly from people who have taken the path you’re thinking about." /><FeatureCard icon="layers" number="03" title="Think together" text="Bring a hard problem into a room full of different perspectives. Leave with a next step." /><FeatureCard icon="book" number="04" title="Stories that stick" text="A living library of real journeys, useful detours, and lessons learned along the way." /></div></section>
          <section className="human-banner"><div className="human-banner-mark"><span className="brand-mark">h<span>i</span></span></div><div><span className="eyebrow">POWERED BY HUMAN INTELLIGENCE</span><h2>The best thing you can find online<br className="desktop-break" /> is still <em>another person.</em></h2></div><button className="btn btn-primary" onClick={() => user ? createPost() : openAuth()}>Find your people <Icon name="arrow" size={16} /></button></section>
          <footer className="page-footer"><span>© 2026 HI — Human Intelligence</span><span>Thoughtful by design. Human, always.</span><div className="footer-links"><button onClick={() => choosePage("about")}>About HI</button><button onClick={() => choosePage("pricing")}>Pricing</button><button onClick={() => choosePage("blog")}>Blog</button><button onClick={() => choosePage("contact")}>Contact <Icon name="arrow" size={13} /></button></div></footer>
        </>}

        {page === "community" && <><PageTitle eyebrow="A NETWORK OF REAL PEOPLE" title="Community" description="The best answers start with a better conversation. Bring what you know, and stay curious about what you don’t." actionLabel="Start a conversation" onAction={createPost} />
          <div className="community-toolbar"><div className="filter-tabs">{["For you", "Discussions", "Questions", "Experiences", "Ideas"].map((filter) => <button key={filter} className={feedFilter === filter ? "filter-tab active" : "filter-tab"} onClick={() => setFeedFilter(filter)}>{filter}</button>)}</div><span className="feed-signal"><span className="live-indicator" /> People are sharing right now</span></div>
          <div className="compose-card compose-wide"><Avatar name={user?.name ?? "You"} size="md" /><button onClick={createPost}>{user ? "What’s on your mind?" : "Share a question or something you’ve learned…"}</button><button className="btn btn-secondary btn-small" onClick={createPost}><Icon name="plus" size={15} /> Create post</button></div>
          {loading ? <PostSkeletons /> : visiblePosts.length ? <div className="post-list community-feed">{visiblePosts.map(renderPost)}</div> : <EmptyState icon="search" title="No conversations found" detail="Try another search, or be the person who starts this conversation." action="Write a post" onAction={createPost} />}
          <div className="feed-end-note"><span className="brand-mark brand-mark-mini">h<span>i</span></span><span>You’re in good company. Every voice here is human.</span></div>
        </>}

        {page === "projects" && <><PageTitle eyebrow="MAKE SOMETHING THAT MATTERS" title="Build together." description="Good ideas get better with other people in the room. Find a project to join, or bring one of your own." actionLabel="Share a project" onAction={createProject} /><div className="project-toolbar"><div className="filter-tabs">{["All projects", "My projects"].map((filter) => <button key={filter} className={projectFilter === filter ? "filter-tab active" : "filter-tab"} onClick={() => setProjectFilter(filter)}>{filter}{filter === "My projects" && user ? <span className="tab-count">{projects.filter((project) => project.creatorId === user.id).length}</span> : null}</button>)}</div><span className="results-count">{filteredProjects.length} thoughtful projects</span></div>{loading ? <ProjectSkeletons /> : filteredProjects.length ? <div className="project-grid">{filteredProjects.map((project) => <ProjectCard key={project.id} project={project} currentUser={user} onEdit={editProject} onDelete={(item) => void handleDeleteProject(item)} onConnect={onConnectProject} />)}</div> : <EmptyState icon="layers" title="Your next big thing starts here" detail="There are no projects in this view yet. Put an idea out into the world and see who finds it." action="Share a project" onAction={createProject} />}<div className="project-bottom-note"><Icon name="verified" size={16} /><span>Good collaboration starts with trust. Show up as you are, and make room for different perspectives.</span></div></>}

        {page === "mentors" && <><PageTitle eyebrow="A LITTLE WISDOM GOES A LONG WAY" title="Learn from someone." description="Real people, generous with what they’ve learned. Ask a specific question. Leave with a perspective you can use." /><div className="mentor-intro-card"><div className="mentor-intro-icon"><Icon name="spark" size={22} /></div><div><span className="eyebrow">MENTORSHIP, WITHOUT THE GATEKEEPING</span><h3>One honest conversation can change your direction.</h3><p>Find the right person for the question you’re carrying. No pitch decks. No pressure to have it all figured out.</p></div><button className="btn btn-secondary btn-small" onClick={() => user ? notify("Your mentorship request is ready to start from your profile.") : openAuth()}>Become a mentor <Icon name="arrow" size={14} /></button></div><div className="mentor-card-grid">{(mentors.length ? mentors : []).map((mentor, index) => { const note = mentorNotes[mentor.name] ?? { focus: mentor.headline, note: "Open to a thoughtful conversation.", color: "blue" }; return <article className="mentor-card" key={mentor.id}><div className={`mentor-card-cover mentor-cover-${note.color}`}><span className="mentor-availability"><span /> Open to connect</span><span className="mentor-orbit-icon"><Icon name={index % 2 ? "lightbulb" : "spark"} size={20} /></span></div><div className="mentor-card-body"><div className="mentor-card-person"><Avatar name={mentor.name} size="lg" verified={mentor.verified} /><div><h3>{mentor.name}</h3><span>{note.focus}</span></div></div><p>{note.note}</p><div className="mentor-tags"><span>Career clarity</span><span>30 min</span></div><button className="btn btn-secondary btn-full" onClick={() => user ? notify(`A note to ${mentor.name} is ready to write.`) : openAuth()}>Ask for a conversation <Icon name="arrow" size={15} /></button></div></article>; })}</div><div className="mentor-note"><Icon name="heart" size={17} /><p>Mentorship on HI is a gift, not a funnel. Everyone can offer what they know and ask for what they need.</p></div></>}

        {page === "rooms" && <><PageTitle eyebrow="THINKING IS BETTER TOGETHER" title="Think rooms." description="Live, small-group conversations around the questions that don’t have a quick answer." /><div className="rooms-feature"><div className="room-live-art"><div className="room-avatars"><Avatar name="Maya Chen" size="lg" /><Avatar name="Theo Park" size="lg" /><Avatar name="Aisha Rahman" size="lg" /><Avatar name="Elena García" size="lg" /></div><div className="room-wave"><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /></div><span className="room-ambient">voices, ideas, new angles</span></div><div className="rooms-feature-copy"><span className="eyebrow"><span className="live-indicator" /> HAPPENING RIGHT NOW</span><h2>Come in with a question.<br /><em>Leave with a new lens.</em></h2><p>Small rooms, real voices, no awkward networking. Pull up a chair and add your perspective.</p><div className="room-hosts"><div className="avatar-stack"><Avatar name="Maya Chen" size="sm" /><Avatar name="Theo Park" size="sm" /><Avatar name="Aisha Rahman" size="sm" /></div><span>People are here now</span></div></div></div><div className="room-section-head"><div><span className="eyebrow">OPEN ROOMS</span><h2>Find a conversation.</h2></div><span className="feed-signal"><span className="live-indicator" /> 7 rooms active</span></div><div className="room-grid">{[{ name: "The first 90 days", topic: "Careers · honest beginnings", count: 8, host: "Aisha Rahman", color: "room-mint", time: "Live now" }, { name: "When a prototype becomes a product", topic: "Startups · messy middle", count: 6, host: "Theo Park", color: "room-blue", time: "Live now" }, { name: "Better questions for better research", topic: "Science · shared practice", count: 11, host: "Elena García", color: "room-lilac", time: "Live now" }, { name: "A portfolio that feels like you", topic: "Design · work in progress", count: 4, host: "Maya Chen", color: "room-peach", time: "Starting soon" }].map((room) => { const joined = joinedRooms.includes(room.name); return <article className="room-card" key={room.name}><div className={`room-card-art ${room.color}`}><span className="room-card-time"><span />{room.time}</span><Icon name="message" size={28} /></div><div className="room-card-body"><span className="eyebrow">{room.topic}</span><h3>{room.name}</h3><div className="room-card-meta"><span><Avatar name={room.host} size="sm" /> Hosted by {room.host.split(" ")[0]}</span><span><Icon name="people" size={14} /> {room.count + (joined ? 1 : 0)} people</span></div><button className={joined ? "btn btn-joined btn-full" : "btn btn-secondary btn-full"} onClick={() => { if (!user) { openAuth(); return; } setJoinedRooms((current) => joined ? current.filter((item) => item !== room.name) : [...current, room.name]); notify(joined ? "You left the think room." : "You’re in. Say hello when you’re ready."); }}>{joined ? <><Icon name="check" size={15} /> Joined · leave room</> : <>Join the room <Icon name="arrow" size={14} /></>}</button></div></article>; })}</div></>}

        {page === "library" && <><PageTitle eyebrow="LESSONS ONLY LIFE CAN TEACH" title="Experience, collected." description="Honest field notes from real people. The detours, the small breakthroughs, the parts left out of the highlight reel." actionLabel="Share your story" onAction={createPost} /><div className="library-feature"><div className="library-feature-art"><span className="library-sun" /><span className="library-horizon horizon-one" /><span className="library-horizon horizon-two" /><span className="library-label">FIELD NOTE Nº 018</span><div className="library-art-quote">“The code gets easier.<br />Understanding context<br />is the real superpower.”</div></div><div className="library-feature-copy"><span className="eyebrow">A NOTE FROM THE COMMUNITY</span><h2>First jobs, real talk.</h2><p>For the things you learn by showing up, asking a better question, and listening to someone who’s been there before.</p><div className="library-feature-author"><Avatar name="Aisha Rahman" size="md" verified /><div><strong>Aisha Rahman</strong><span>Engineer · London, UK</span></div></div><button className="text-link" onClick={() => { setQuery("first engineering job"); setPage("community"); }}>Read the field note <Icon name="arrow" size={14} /></button></div></div><div className="library-collection-head"><div><span className="eyebrow">COMMUNITY FIELD NOTES</span><h2>Stories worth keeping.</h2></div><span className="results-count">{filteredPosts.length} experiences</span></div>{loading ? <PostSkeletons /> : visiblePosts.length ? <div className="post-list community-feed">{visiblePosts.map(renderPost)}</div> : <EmptyState icon="book" title="The library is getting started" detail="Share an experience someone else might need to hear." action="Share your story" onAction={createPost} />}</>}

        {page === "challenges" && <><PageTitle eyebrow="A DAILY EXERCISE IN BEING HUMAN" title="Think a little differently." description="Small prompts. Big perspectives. The community decides which ideas make us think again." /><div className="challenge-feature"><div className="challenge-art"><div className="challenge-orb orb-large" /><div className="challenge-orb orb-small" /><span className="challenge-number">CHALLENGE 014</span><span className="challenge-art-caption">WHAT IF WE<br /><em>LOOKED CLOSER?</em></span><div className="challenge-live"><span className="live-indicator" /> VOTING OPEN · 18H LEFT</div></div><div className="challenge-copy"><span className="eyebrow">THIS WEEK’S QUESTION</span><h2>What’s one everyday problem you’d solve if you could bring three people together?</h2><p>Not three experts. Three people with completely different lives. Tell us what you’d build, who you’d invite, and why.</p><div className="challenge-stats"><span><strong>126</strong> ideas shared</span><span><strong>18h</strong> left to vote</span></div><button className="btn btn-primary" onClick={() => { if (!user) { openAuth(); return; } setChallengeVote("your-idea"); notify("Your idea has been added to this week’s challenge."); }}>Share your idea <Icon name="arrow" size={15} /></button></div></div><div className="challenge-ideas-head"><div><span className="eyebrow">COMMUNITY PICKS</span><h2>Ideas that stayed with us.</h2></div><span className="results-count"><Icon name="trend" size={14} /> Most thoughtful</span></div><div className="idea-grid">{[{ id: "01", who: "Maya Chen", title: "A quiet hour in every city", body: "Bring an urban gardener, a night-shift nurse, and a transit designer together to make a public place that works for people who need somewhere calm.", votes: 86, color: "idea-mint" }, { id: "02", who: "Theo Park", title: "The repair café, but for knowledge", body: "A weekly gathering where people bring the thing they’re stuck on—not to get an answer, but to see it through someone else’s eyes.", votes: 72, color: "idea-blue" }, { id: "03", who: "Elena García", title: "A map made of tiny acts of care", body: "What if neighbors marked the little things they’ve built to help each other? A shared picture of what makes a place feel like home.", votes: 59, color: "idea-lilac" }].map((idea) => <article className={`idea-card ${idea.color}`} key={idea.id}><span className="idea-number">IDEA {idea.id}</span><h3>{idea.title}</h3><p>{idea.body}</p><div className="idea-card-foot"><span><Avatar name={idea.who} size="sm" />{idea.who}</span><button className={challengeVote === idea.id ? "idea-vote voted" : "idea-vote"} onClick={() => { if (!user) { openAuth(); return; } setChallengeVote(challengeVote === idea.id ? null : idea.id); }}><Icon name="heart" size={15} /> {idea.votes + (challengeVote === idea.id ? 1 : 0)}</button></div></article>)}</div></>}

        {page === "saved" && <><PageTitle eyebrow="YOUR PERSONAL READING LIST" title="Keep the good ones." description="Thoughtful questions and perspectives you’ve saved for a quieter moment." /><div className="filter-tabs saved-tabs"><button className="filter-tab active">All saved <span className="tab-count">{savedIds.length}</span></button></div>{loading ? <PostSkeletons /> : visiblePosts.length ? <div className="post-list community-feed">{visiblePosts.map(renderPost)}</div> : <EmptyState icon="bookmark" title="Nothing saved just yet" detail="When a conversation resonates, save it. You’ll find it right here." action="Explore the community" onAction={() => choosePage("community")} />}</>}

        {page === "profile" && <><PageTitle eyebrow="YOUR HUMAN INTELLIGENCE, IN YOUR OWN WORDS" title={user ? "A little more you." : "Your profile starts here."} description={user ? "A living profile of what you know, what you care about, and what you’re here to learn." : "Join the network and show people what makes you, you."} actionLabel={user ? "Edit profile" : "Join HI"} onAction={() => user ? setModal("profile") : openAuth()} />{user ? <div className="profile-layout"><section className="profile-main-card"><div className="profile-cover"><div className="profile-cover-orbit" /><span className="eyebrow"><span className="live-indicator" /> HUMAN, ALWAYS</span></div><div className="profile-identity"><Avatar name={user.name} size="xl" verified={user.verified} /><div><div className="profile-title-row"><h2>{user.name}</h2>{user.verified && <span className="verified-label"><Icon name="verified" size={14} /> Verified human</span>}</div><p>{user.headline}</p>{user.location && <span className="profile-location"><Icon name="pin" size={14} /> {user.location}</span>}</div><button className="btn btn-secondary btn-small profile-edit" onClick={() => setModal("profile")}><Icon name="edit" size={14} /> Edit profile</button></div><div className="profile-bio"><span className="eyebrow">A LITTLE ABOUT ME</span><p>{user.bio || "Add a few words about yourself and the kind of things you love to talk about."}</p></div><div className="profile-chip-section"><span className="eyebrow">THINGS I KNOW</span><div className="tag-row">{user.skills.length ? user.skills.map((skill) => <span className="tag" key={skill}>{skill}</span>) : <button className="text-link" onClick={() => setModal("profile")}>Add a few skills <Icon name="plus" size={13} /></button>}</div></div><div className="profile-chip-section"><span className="eyebrow">THINGS I CARE ABOUT</span><div className="tag-row">{user.interests.length ? user.interests.map((interest) => <span className="tag tag-soft" key={interest}>{interest}</span>) : <button className="text-link" onClick={() => setModal("profile")}>Add your interests <Icon name="plus" size={13} /></button>}</div></div></section><aside className="profile-stats-card"><span className="eyebrow">YOUR CONTRIBUTIONS</span><div className="contribution-score"><span>{user.contributionScore.toLocaleString()}</span><small>contribution points</small></div><div className="profile-stat-line"><span>Conversations started</span><strong>{posts.filter((post) => post.authorId === user.id).length}</strong></div><div className="profile-stat-line"><span>Projects shared</span><strong>{projects.filter((project) => project.creatorId === user.id).length}</strong></div><div className="profile-stat-line"><span>Saved for later</span><strong>{savedIds.length}</strong></div><div className="reputation-note"><Icon name="spark" size={17} /><p>On HI, recognition comes from how you help—not who follows you.</p></div></aside><div className="profile-activity"><div className="section-heading-row"><div><span className="eyebrow">YOUR FOOTPRINT</span><h2>Conversations you’ve started</h2></div><button className="text-link" onClick={createPost}>Write something <Icon name="arrow" size={14} /></button></div>{posts.filter((post) => post.authorId === user.id).length ? <div className="post-list">{posts.filter((post) => post.authorId === user.id).map(renderPost)}</div> : <EmptyState icon="message" title="Your first story starts with you" detail="Share a question or experience and make it easier for someone else to join in." action="Start a conversation" onAction={createPost} />}</div></div> : <div className="profile-guest-card"><div className="profile-guest-visual"><Avatar name="Curious human" size="xl" /><span className="guest-star star-a">✳</span><span className="guest-star star-b">✦</span></div><div><span className="eyebrow">YOUR SPACE, YOUR PERSPECTIVE</span><h2>A profile that grows<br />with what you give.</h2><p>Collect your skills, interests, projects, and the small ways you make someone else’s day easier.</p><button className="btn btn-primary" onClick={() => openAuth()}>Create your profile <Icon name="arrow" size={15} /></button></div></div>}</>}

        {page === "settings" && <><PageTitle eyebrow="YOUR ACCOUNT, YOUR CALL" title="Settings." description="Take care of the details. Your data and your time belong to you." />{user ? <div className="settings-layout"><section className="settings-card"><div className="settings-section"><span className="eyebrow">ACCOUNT</span><div className="settings-row"><div><strong>Email address</strong><span>{user.email}</span></div><span className="settings-status"><Icon name="check" size={13} /> Verified</span></div><div className="settings-row"><div><strong>Community access</strong><span>HI is for people aged 18 and older.</span></div><span className="verified-label"><Icon name="verified" size={13} /> 18+</span></div></div><div className="settings-section"><span className="eyebrow">YOUR PROFILE</span><div className="settings-row"><div><strong>Profile details</strong><span>Name, bio, skills, and interests.</span></div><button className="btn btn-secondary btn-small" onClick={() => setModal("profile")}>Edit profile <Icon name="arrow" size={13} /></button></div></div><div className="settings-section settings-danger"><span className="eyebrow">SESSION</span><div className="settings-row"><div><strong>Sign out of HI</strong><span>You can come back whenever you’re ready.</span></div><button className="btn btn-danger btn-small" onClick={() => void logout()}><Icon name="logout" size={14} /> Sign out</button></div></div></section><aside className="settings-aside"><div className="settings-aside-icon"><Icon name="heart" size={20} /></div><h3>Humans first.<br />Always.</h3><p>Your real name, lived experience, and perspective make HI what it is. Thank you for showing up.</p><button className="text-link" onClick={() => choosePage("about")}>Read our principles <Icon name="arrow" size={14} /></button></aside></div> : <div className="profile-guest-card"><div><span className="eyebrow">YOUR ACCOUNT IS WAITING</span><h2>Make your space<br />on HI.</h2><p>Sign in or join the network to manage your profile and preferences.</p><button className="btn btn-primary" onClick={() => openAuth("login")}>Sign in to HI <Icon name="arrow" size={15} /></button></div></div>}</>}

        {page === "about" && <><PageTitle eyebrow="A HUMAN IDEA, MADE REAL" title="Technology should bring us closer." description="HI exists because information is abundant, but experience, empathy, and the feeling of being understood still come from people." actionLabel="Join the network" onAction={() => openAuth()} /><section className="about-statement"><span className="eyebrow">WHAT WE BELIEVE</span><h2>AI can give you an answer.<br />A person can tell you <em>what it meant.</em></h2><p>We’re not here to replace new tools. We’re here to remember what they can’t replace: the wisdom of lived experience, the generosity of a good mentor, and the unexpected insight that only happens when different people think together.</p><div className="about-principles"><div><span>01</span><h3>Experience over expertise.</h3><p>Every person has something worth sharing. Credentials help you find context, but they don’t determine whose story matters.</p></div><div><span>02</span><h3>Contribution over attention.</h3><p>Recognition on HI grows from being useful, generous, and thoughtful—not from collecting followers.</p></div><div><span>03</span><h3>Connection over convenience.</h3><p>We make space for the conversations worth having, even when the answer isn’t instant.</p></div></div></section><section className="mission-card"><span className="eyebrow">OUR NORTH STAR</span><h2>A world where technology<br />makes more room for <em>people.</em></h2><p>One question, story, and generous conversation at a time.</p><button className="btn btn-primary" onClick={() => openAuth()}>Be part of it <Icon name="arrow" size={15} /></button></section></>}
        {page === "pricing" && <><PageTitle eyebrow="A NETWORK SHOULD BE OPEN" title="Human connection, without a paywall." description="HI is built on the belief that useful knowledge gets better when more people can reach it. The core network is free to join." actionLabel="Join HI for free" onAction={() => openAuth()} /><section className="pricing-hero-card"><div className="pricing-hero-orbit"><span className="brand-mark">h<span>i</span></span></div><div><span className="eyebrow">THE HUMAN NETWORK</span><h2>Good conversations<br /><em>are free.</em></h2><p>Every person deserves access to mentorship, lived experience, and a community that wants to help. No ads. No follower economy. No fee to be heard.</p></div><div className="pricing-free"><span>$</span><strong>0</strong><small>to join · always</small></div></section><div className="pricing-grid"><article className="pricing-card pricing-featured"><span className="eyebrow">THE WHOLE NETWORK</span><h3>HI Community</h3><div className="pricing-amount">Free <span>forever</span></div><p>Everything you need to learn, share, build, and find your people.</p><ul><li><Icon name="check" size={14} /> Human discussions & experience library</li><li><Icon name="check" size={14} /> Mentorship and Think Rooms</li><li><Icon name="check" size={14} /> Communities, projects & challenges</li><li><Icon name="check" size={14} /> Your profile and contribution history</li></ul><button className="btn btn-primary btn-full" onClick={() => openAuth()}>Join the network <Icon name="arrow" size={14} /></button></article><article className="pricing-card"><span className="eyebrow">FOR PEOPLE WHO BELIEVE IN THIS</span><h3>HI Supporter</h3><div className="pricing-amount">On us <span>for now</span></div><p>We’re building a sustainable, human-first network. Supporter options will come later, without changing what’s free.</p><div className="supporter-note"><Icon name="heart" size={17} /><span>No ads, no data sales, no paid reach. That’s the promise.</span></div><button className="btn btn-secondary btn-full" onClick={() => notify("Supporter options are still being thoughtfully designed. The network is free for everyone.")}>See what we’re building <Icon name="arrow" size={14} /></button></article></div><div className="pricing-promise"><Icon name="verified" size={17} /><span>Our promise: the human part of HI will always be free to access.</span><button className="text-link" onClick={() => choosePage("about")}>Why we believe this <Icon name="arrow" size={13} /></button></div></>}

        {page === "blog" && <><PageTitle eyebrow="NOTES FROM A MORE HUMAN INTERNET" title="The HI journal." description="Ideas, field notes, and honest questions about how we learn from one another." /><div className="blog-feature"><div className="blog-feature-art"><div className="blog-feature-shape shape-one" /><div className="blog-feature-shape shape-two" /><span className="eyebrow">THE HI JOURNAL · 6 MIN READ</span><div><span className="blog-feature-kicker">A BETTER QUESTION</span><h2>What if the most useful thing online was a person?</h2></div></div><div className="blog-feature-copy"><span className="eyebrow">WHY WE’RE HERE</span><p>There’s no shortage of answers. There is still a shortage of the context, kindness, and honest experience that help an answer become useful.</p><button className="text-link" onClick={() => choosePage("about")}>Read our point of view <Icon name="arrow" size={14} /></button></div></div><div className="blog-article-grid">{[{ category: "FIELD NOTES", title: "Your first job is a lesson in context", excerpt: "The small rituals that help you understand how a team thinks—not just how its code works.", author: "Aisha Rahman", time: "6 min", icon: "layers", color: "blog-mint" }, { category: "HUMAN BY DESIGN", title: "Mentorship isn’t a shortcut. It’s a conversation.", excerpt: "Why the best mentoring starts with a question you’re actually carrying this week.", author: "Elena García", time: "4 min", icon: "people", color: "blog-lilac" }, { category: "BUILDING TOGETHER", title: "A portfolio is a conversation, not a museum", excerpt: "Show your thinking, the decisions that changed, and what you would do differently next time.", author: "Maya Chen", time: "5 min", icon: "spark", color: "blog-peach" }].map((article) => <article className="blog-article" key={article.title}><div className={`blog-article-art ${article.color}`}><span className="blog-article-icon"><Icon name={article.icon} size={20} /></span><span className="eyebrow">{article.category}</span><span className="blog-art-lines" /></div><div className="blog-article-copy"><div className="blog-meta"><span>{article.author}</span><span>·</span><span>{article.time} read</span></div><h3>{article.title}</h3><p>{article.excerpt}</p><button className="text-link" onClick={() => choosePage("library")}>Explore the field notes <Icon name="arrow" size={13} /></button></div></article>)}</div><div className="blog-bottom-note"><Icon name="heart" size={16} /><span>Written by people, for people. Have a story worth sharing?</span><button className="text-link" onClick={() => user ? createPost() : openAuth()}>Share your experience <Icon name="arrow" size={13} /></button></div></>}

        {page === "contact" && <><PageTitle eyebrow="A REAL PERSON WILL READ THIS" title="Talk to a human." description="Questions, ideas, feedback, or a story you think we should hear. We’re listening." /><div className="contact-layout"><section className="contact-aside"><div className="contact-visual"><span className="contact-ring contact-ring-a" /><span className="contact-ring contact-ring-b" /><span className="contact-center"><Icon name="message" size={25} /></span><span className="contact-node contact-node-a">M</span><span className="contact-node contact-node-b">A</span><span className="contact-node contact-node-c">H</span></div><span className="eyebrow">NO CHATBOT IN THIS INBOX</span><h2>Tell us what<br />you’re thinking.</h2><p>Every message goes to a real person on the HI team. We’ll get back to you as soon as we can.</p><div className="contact-promise"><Icon name="clock" size={15} /><span>Usually within 2 working days</span></div><div className="contact-promise"><Icon name="globe" size={15} /><span>Made for a community everywhere</span></div></section><ContactForm onSent={() => notify("Your note is with the HI team. Thanks for reaching out.")} /></div></>}
      </div>
    </section>

    {modal === "auth" && <AuthDialog mode={authMode} setMode={setAuthMode} onClose={() => setModal(null)} onSuccess={(nextUser) => void finishAuth(nextUser)} />}
    {modal === "post" && <PostEditor post={editingPost} onClose={() => { setModal(null); setEditingPost(null); }} onSubmit={handlePostSubmit} />}
    {modal === "project" && <ProjectEditor project={editingProject} onClose={() => { setModal(null); setEditingProject(null); }} onSubmit={handleProjectSubmit} />}
    {modal === "profile" && user && <ProfileEditor user={user} onClose={() => setModal(null)} onSubmit={handleProfileSubmit} />}
    {toast && <div className={`toast toast-${toast.kind}`} role="status"><span className="toast-symbol"><Icon name={toast.kind === "success" ? "check" : "close"} size={15} /></span>{toast.text}<button className="toast-close" onClick={() => setToast(null)} aria-label="Dismiss"><Icon name="close" size={15} /></button></div>}
  </main>;
}

function NavButton({ icon, label, pageKey, active, onClick, badge }: { icon: string; label: string; pageKey: PageKey; active: PageKey; onClick: (page: PageKey) => void; badge: ReactNode }) {
  return <button className={`nav-button ${active === pageKey ? "nav-active" : ""}`} onClick={() => onClick(pageKey)}><Icon name={icon} size={17} /><span>{label}</span>{badge && <span className="nav-badge">{badge}</span>}</button>;
}

function NetworkArt() {
  return <svg className="network-art" viewBox="0 0 540 410" fill="none" aria-hidden="true"><g className="network-lines"><path d="M260 94 355 142 430 88M260 94 205 178 355 142M205 178 108 132M205 178 284 266 394 224M355 142 394 224 462 290M108 132 115 250 205 178M115 250 206 324 284 266M206 324 394 224M284 266 430 88M355 142 480 166" /><path d="M260 94 284 266M205 178 394 224M108 132 260 94M115 250 394 224" /></g><g className="network-nodes"><circle cx="260" cy="94" r="8" /><circle cx="355" cy="142" r="7" /><circle cx="430" cy="88" r="5" /><circle cx="205" cy="178" r="6" /><circle cx="108" cy="132" r="6" /><circle cx="394" cy="224" r="8" /><circle cx="284" cy="266" r="5" /><circle cx="115" cy="250" r="4" /><circle cx="206" cy="324" r="6" /><circle cx="462" cy="290" r="5" /><circle cx="480" cy="166" r="4" /></g><circle cx="355" cy="142" r="17" className="node-halo" /><circle cx="205" cy="178" r="14" className="node-halo node-halo-delay" /></svg>;
}

function PageTitle({ eyebrow, title, description, actionLabel, onAction }: { eyebrow: string; title: string; description: string; actionLabel?: string; onAction?: () => void }) {
  return <div className="page-title-block"><div className="page-title-copy"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{description}</p></div>{actionLabel && onAction && <button className="btn btn-primary title-action" onClick={onAction}><Icon name="plus" size={16} />{actionLabel}</button>}</div>;
}

function FeatureCard({ icon, number, title, text }: { icon: string; number: string; title: string; text: string }) {
  return <article className="feature-card"><div className="feature-card-top"><span className="feature-icon"><Icon name={icon} size={18} /></span><span>{number}</span></div><h3>{title}</h3><p>{text}</p><span className="feature-link"><Icon name="arrow" size={14} /></span></article>;
}

function ContactForm({ onSent }: { onSent: () => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [topic, setTopic] = useState("General question");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setBusy(true); setError("");
    try {
      await api("/api/contact", { method: "POST", body: JSON.stringify({ name, email, topic, message }) });
      setSent(true); onSent();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Couldn’t send your note. Please try again.");
    } finally { setBusy(false); }
  };
  if (sent) return <div className="contact-form contact-thanks"><span className="contact-success-icon"><Icon name="check" size={22} /></span><span className="eyebrow">MESSAGE RECEIVED</span><h2>Thanks for reaching out.</h2><p>Your note is safely with the HI team. A human will be in touch as soon as we can.</p><button className="btn btn-secondary" onClick={() => { setSent(false); setMessage(""); }}>Send another note <Icon name="arrow" size={14} /></button></div>;
  return <form className="contact-form" onSubmit={submit}><div className="contact-form-heading"><span className="eyebrow">WRITE US A NOTE</span><h2>What’s on your mind?</h2><p>All fields stay with our team. We’ll never sell your information.</p></div><div className="form-row"><label className="field-label">Your name<input className="text-input" autoComplete="name" minLength={2} maxLength={100} required value={name} onChange={(event) => setName(event.target.value)} placeholder="A name we can say hello to" /></label><label className="field-label">Email address<input className="text-input" autoComplete="email" type="email" maxLength={255} required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@example.com" /></label></div><label className="field-label">What’s this about?<select className="text-input" value={topic} onChange={(event) => setTopic(event.target.value)}><option>General question</option><option>Partnership</option><option>Press & storytelling</option><option>Safety & community</option><option>Something else</option></select></label><label className="field-label">Your message<textarea className="text-input text-area" required minLength={20} maxLength={4000} rows={6} value={message} onChange={(event) => setMessage(event.target.value)} placeholder="Tell us a little about it…" /></label>{error && <p className="form-error" role="alert">{error}</p>}<div className="contact-submit-row"><span className="form-footnote"><Icon name="heart" size={14} /> Read by a person. Always.</span><button className="btn btn-primary" disabled={busy}>{busy ? <span className="button-spinner" /> : null}Send your note<Icon name="send" size={14} /></button></div></form>;
}

function PostSkeletons() {
  return <div className="skeleton-list" aria-label="Loading conversations"><span className="skeleton-card" /><span className="skeleton-card" /></div>;
}
function ProjectSkeletons() {
  return <div className="project-grid skeleton-projects" aria-label="Loading projects"><span className="skeleton-project" /><span className="skeleton-project" /><span className="skeleton-project" /></div>;
}
